Melexis Python Exception Classes to be used in other projects.


