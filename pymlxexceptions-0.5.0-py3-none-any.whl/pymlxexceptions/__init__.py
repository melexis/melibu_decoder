""" Melexis Exception Classes """
from pymlxexceptions.__version__ import version

__version__ = version

__copyright__ = "Copyright Melexis N.V."

__all__ = ['PyMlxBaseException']

from pymlxexceptions.exceptions import PyMlxBaseException
