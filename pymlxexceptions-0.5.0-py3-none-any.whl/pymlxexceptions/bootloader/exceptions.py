"""
Python module which provides all the melexis physical layer exceptions

Copyright Melexis N.V.

This product includes software developed at Melexis N.V. (https://www.melexis.com).

Melexis N.V. has provided this code according to LICENSE file attached to repository
"""
from pymlxexceptions import PyMlxBaseException


class BootloaderBaseException(PyMlxBaseException):
    """ Custom base exception for the pymlxexceptions lin module """


class CommunicationError(BootloaderBaseException):
    """ Custom exception for communication error situations """


class VerificationError(BootloaderBaseException):
    """ Custom exception for verification error situations """


class DeviceNotSupported(BootloaderBaseException):
    """ Custom exception for device not supported situations """


class DeviceProtected(BootloaderBaseException):
    """ Custom exception for device protected situations """
