""" Melexis Bootloader Exception Classes """

__all__ = [
    "BootloaderBaseException",
    "CommunicationError",
    "VerificationError",
    "DeviceNotSupported",
    "DeviceProtected",
]

from pymlxexceptions.bootloader.exceptions import BootloaderBaseException

from pymlxexceptions.bootloader.exceptions import CommunicationError
from pymlxexceptions.bootloader.exceptions import VerificationError
from pymlxexceptions.bootloader.exceptions import DeviceNotSupported
from pymlxexceptions.bootloader.exceptions import DeviceProtected
