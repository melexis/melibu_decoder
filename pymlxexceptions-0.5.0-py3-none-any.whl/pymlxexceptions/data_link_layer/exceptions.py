"""
Python module which provides all the melexis data link layer exceptions

Copyright Melexis N.V.

This product includes software developed at Melexis N.V. (https://www.melexis.com).

Melexis N.V. has provided this code according to LICENSE file attached to repository
"""
from pymlxexceptions import PyMlxBaseException


class DataLinkLayerBaseException(PyMlxBaseException):
    """ Custom base exception for the data link layer """


class Timeout(DataLinkLayerBaseException):
    """ Custom exception for slave response timeout error situations """


class Collision(DataLinkLayerBaseException):
    """ Custom exception for collision error situations """


class CrcError(DataLinkLayerBaseException):
    """ Custom exception for crc error situations """
