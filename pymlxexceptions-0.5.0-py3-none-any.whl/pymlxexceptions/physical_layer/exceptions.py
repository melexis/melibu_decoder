"""
Python module which provides all the melexis physical layer exceptions

Copyright Melexis N.V.

This product includes software developed at Melexis N.V. (https://www.melexis.com).

Melexis N.V. has provided this code according to LICENSE file attached to repository
"""
from pymlxexceptions import PyMlxBaseException


class PhysicalLayerBaseException(PyMlxBaseException):
    """ Custom base exception for the pymlxexceptions lin module """


class BusVoltageError(PhysicalLayerBaseException):
    """ Custom exception for incorrect bus voltage error situations """


class BusShort(PhysicalLayerBaseException):
    """ Custom exception for bus short cut error situations """


class StopBitError(PhysicalLayerBaseException):
    """ Custom exception for stop bit level error situations """
