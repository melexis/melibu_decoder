"""
Python module which provides all the melexis transport layer exceptions

Copyright Melexis N.V.

This product includes software developed at Melexis N.V. (https://www.melexis.com).

Melexis N.V. has provided this code according to LICENSE file attached to repository
"""
from pymlxexceptions import PyMlxBaseException


class TransportLayerBaseException(PyMlxBaseException):
    """ Custom base exception for the transport layer """


class NoResponse(TransportLayerBaseException):
    """ Custom exception for no response error situations """


class UnexpectedResponse(TransportLayerBaseException):
    """ Custom exception for unexpected response error situations """


class InvalidNad(TransportLayerBaseException):
    """ Custom exception for invalid nad in response error situations """


class InvalidPci(TransportLayerBaseException):
    """ Custom exception for invalid pci in response error situations """


class InvalidFrameCounter(TransportLayerBaseException):
    """ Custom exception for invalid frame counter in response error situations """


class InvalidRsid(TransportLayerBaseException):
    """ Custom exception for invalid RSID in response error situations """
