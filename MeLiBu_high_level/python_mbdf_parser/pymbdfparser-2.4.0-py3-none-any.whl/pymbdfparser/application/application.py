""" Module for filling up the model with the reader's data."""
import logging
import re
import os
from collections import OrderedDict
from operator import attrgetter
from pathlib import Path

from natsort import natsorted
from pyparsing import ParseException

from pymbdfparser import MbdfError, MbdfFrameNotFoundError, MbdfNodeNotFoundError, MbdfReader, ScriptReader
from pymbdfparser.model.mbdf_model import MbdfModel, SUPPORTED_PROTOCOLS
from pymbdfparser.model.node import BroadcastNode, SlaveNode, MasterNode
from pymbdfparser.model.script_commands import (DigitalInput, DigitalOutput, ExecuteScript, PowerSupply,
                                                ScriptAutoaddressFrame, ScriptWakeupFrame, SetBaudrate)
from pymbdfparser.model.script_frame import ScriptFrameBase, ScriptFrameMelibu1, ScriptFrameMelibu2
from pymbdfparser.model.signal import Signal
from pymbdfparser.model.frame import CommandFrameMelibu1, LedFrameMelibu1, CommandFrameMelibu2, LedFrameMelibu2
from pymbdfparser.model.schedule_table import ScheduleTable, ScriptTable
from pymbdfparser.model.signal_encoding_type import LogicalEncoding, PhysicalEncoding, SignalEncodingType
from pymbdfparser.model.signal_representation import SignalRepresentation

LOGGER = logging.getLogger('pymbdfparser')


class ErrorsHandler(logging.Handler):
    """
    Custom handler for logging module on error level to keep track of the amount of errors raised.

    Attributes:
        error_count (int): Integer that increases by 1 when this handler gets called.
    """
    def __init__(self):
        """ Constructor of ErrorsHandler class."""
        super().__init__()
        self.error_count = 0

    def emit(self, record):
        """
        If a formatter is specified, it is used to format the record.
        The formatted has been specified in bus_nodegen.py.

        Args:
            record (str): Record of the log.
        """
        self.error_count += 1


class ParserApplication:
    """ Class for organization of parsing/storage workflow. """

    def __init__(self, mbdf_file, script_file=None):
        """
        Constructor of ParserApplication class

        Args:
            mbdf_file (Path): Path to input MBDF-file.
            script_file (Path): Path to the optional input script file.
        """
        logging.basicConfig(format='%(levelname)s: %(message)s')
        self.reader = MbdfReader()
        self.mbdf_file = mbdf_file
        self.script_reader = ScriptReader()
        self.script_file = script_file
        self.filler = self.FillModel()
        self.model = None
        self.error_handler = ErrorsHandler()
        self.error_handler.setLevel(logging.ERROR)
        LOGGER.addHandler(self.error_handler)

    def run(self, strict_mbdf_name=True, **config):
        """ Processes MBDF and optional MBDFSCR and stores data in model. """
        self.exit_on_error()
        ScriptTable.strict_filename_checking = strict_mbdf_name

        inputs = [
            (self.mbdf_file, self.reader, self._store_mbdf_data),
            (self.script_file, self.script_reader, self._store_script_data),
        ]
        for file_path, reader, storage_func in inputs:
            if not file_path or not reader:
                continue
            LOGGER.info("Parsing file '%s'...", os.path.basename(file_path))
            try:
                with open(file_path, 'r', encoding='utf-8') as file:
                    file_content = file.read()
                data = reader.parse_all(file_content)
            except ParseException as err:
                # Clarify any vague error messages
                vague_msg_regex = re.compile(
                    r"Missing one or more required elements \((?P<sections>.+)\), "
                    r"found '\w+'  \(at char \d+\), \(line:\d+, col:\d+\)"
                )
                match = vague_msg_regex.match(str(err))
                if match:
                    first_section = match.group('sections').split(', ')[0]
                    err = f"MBDF syntax error in section {first_section!r}"
                raise MbdfError(err)  # pylint: disable=raise-missing-from

            storage_func(data, file_path, **config)
            LOGGER.info("Parsing file '%s'...done", os.path.basename(file_path))
        self._postprocessing()
        self.exit_on_error()

    def _store_mbdf_data(self, data, file_path, **config):
        self.model = self.filler.run(data, file_path, **config)

    def _store_script_data(self, data, file_path, **_):
        self.model.script_table = self.filler.create_script_table(data, file_path)

    def _postprocessing(self):
        all_tables = list(self.model.schedule_tables.values())
        if self.model.script_table is not None:
            all_tables.append(self.model.script_table)

        for table in all_tables:
            self._resolve_scripts(table, [])

    def _resolve_scripts(self, table, script_names):
        execute_scripts = [msg for msg in table.messages if isinstance(msg, ExecuteScript)]
        for msg in execute_scripts:
            local_script_names = script_names.copy()
            with open(msg.path, 'r', encoding='utf-8') as file:
                file_content = file.read()
            data = self.script_reader.parse_all(file_content)
            script_table = self.filler.create_script_table(data, msg.path)
            if script_table.name in local_script_names:
                raise MbdfError("Recursion error while resolving nested ExecuteScript commands: encountered "
                                f"{script_table.name!r} more than once.")
            local_script_names.append(script_table.name)
            self._resolve_scripts(script_table, local_script_names)
            table.replace(msg, script_table.messages)

    def refresh_scheduled_scripts(self, name=None):
        """ Refreshes the contents of scripts, passed inserted via ExecuteScript, in one or all schedule tables.

        Args
            name (str/None): None takes into account all schedule tables; a schedule table name selects a single one.
        """
        if name is None:
            self.model._schedule_tables = {}  # pylint: disable=protected-access
        else:
            del self.model.schedule_tables[name]
        self.filler.fill_model_schedule_tables(name)
        self.filler.validate_script_frame_entries()
        self._postprocessing()
        self.exit_on_error()

    def exit_on_error(self):
        """ Raises a SystemExit with the number of counted errors as exit code

        Note: the counter is reset; useful in case the SystemExit is caught and we continue
        """
        if self.error_handler.error_count:
            count = self.error_handler.error_count
            self.error_handler.error_count = 0
            raise SystemExit(count)

    class FillModel:
        """Class for filling up the model.

        Attributes:
            mdl (MbdfModel): MbdfModel instance to get filled up.
            mbdf_data (ParseResults): Output data of reader.
        """

        def __init__(self):
            """ Constructor of FillModel class """
            self._mdl = None
            self.mbdf_data = None

        def run(self, data, file_path, used_node="", partlogs=""):
            """ Call all functions to fill up the model with the reader's data.

            Args:
                data (ParseResults): Output data of reader.
                file_path (pathlib.Path): Path to the MBDF.
                used_node (str): When set, warnings that are only relevant to other slave nodes are disabled.
                partlogs (str): Configures the visibility of several types of warnings:
                    If character 's' is set, warnings about unused signal encoding types are suppressed.
                    If character 'u' is set, warnings about nodes different from ``used_node``, are enabled.
                    If character 'h' is set, warnings about signals that are packed across a hextet (six-byte
                        section) boundary in frames with a sub-address signal are promoted to an exception.
            """
            self.mbdf_data = data
            self.fill_model_general(file_path)
            self.fill_model_broadcast_nodes()
            self.fill_model_nodes()
            self.fill_model_node_attributes()
            self.fill_model_signals()
            self.fill_model_frames(partlogs=partlogs)
            self.fill_slave_nodes()
            self.fill_model_schedule_tables()
            for node in self._mdl.slave_nodes.values():
                self.check_supported_frames(node, used_node=used_node, partlogs=partlogs)
            self.validate_script_frame_entries()
            self.verify_s2m_signal_subscription()
            self.fill_model_signal_representations(partlogs=partlogs)
            return self._mdl

        def _parse_script_frame(self, entry):
            """ Fill a ScriptFrameMelibu1/ScriptFrameMelibu2 for each recipient of the given entry.

            Args:
                entry (ParseResults): schedule table entry

            Raises:
                MbdfError: Definition of script frame is missing the mandatory parameter <frame_subaddress>
                MbdfError: Definition of script frame contains one too many parameters
                MbdfNodeNotFoundError: One of the message recipients is not named
                in the node list or Node_attributes section.

            Returns:
                list(ScriptFrameMelibu1/ScriptFrameMelibu2): List of script frames, one for each recipient
                in the script table entry.
            """
            msg_objs = []
            frame = self.get_frame(entry["frame_name"], "script file")
            delay_us = self._convert_frame_time(entry['delay'], entry['delay_unit'])
            if self._mdl.bus_protocol_version < 2.0:
                script_frame_class = ScriptFrameMelibu1
                if "int_or_default2" not in entry:
                    raise MbdfError(f"Definition of script frame with name {frame.name!r} is missing the mandatory "
                                    "parameter <frame_subaddress>")
                if isinstance(entry["int_or_default2"], int) and frame.function_type != "Command":
                    # Log a warning here instead of raising an exception, so as not to break old scripts
                    LOGGER.warning(f"ext_instruction should be 'Default' (not '{entry['int_or_default2']!r}') "
                                   f"for frame {frame.name!r} in script table, because it is not a CommandFrame.")

            else:
                script_frame_class = ScriptFrameMelibu2
                if "int_or_default2" in entry:
                    raise MbdfError(f"Definition of script frame with name {frame.name!r} contains one too many "
                                    "parameters")

            for recipient in entry["recipients"]:
                if recipient == "Broadcast":
                    recipient = "Broadcast0"
                node = self.get_node(recipient, "script file", include_broadcast=True)
                msg_obj = script_frame_class(node, frame, model=self._mdl)
                msg_obj.buffer_frame_attribute_signals()
                msg_obj.delay_us = delay_us

                if isinstance(msg_obj, ScriptFrameMelibu1):
                    if isinstance(entry["int_or_default1"], int):
                        msg_obj.sub_address = entry["int_or_default1"]
                    if isinstance(entry["int_or_default2"], int):
                        msg_obj.ext_instruction = entry["int_or_default2"]
                else:
                    if isinstance(entry["int_or_default1"], int):
                        msg_obj.instruction_word = entry["int_or_default1"]

                msg_obj.signal_values = list(entry["data"])
                msg_objs.append(msg_obj)

            return msg_objs

        def create_script_table(self, data, file_path):
            """Returns a ScriptTable based on a script file

            Args:
                data (ParseResults): Output of the reader that contains all parsed data
                file_path (Path): Path to the input script file

            Returns:
                ScriptTable
            """
            mbdf = get_section(data, 'Mbdf', required=True)
            msg_entries = get_section(data, 'Messages', required=True)

            script_table = ScriptTable(file_path.stem, str(mbdf), self._mdl)
            for entry in msg_entries:
                try:
                    cmd = entry.get("cmd")

                    if cmd == 'STOP':
                        if script_table.do_loop:
                            script_table.do_loop = False
                        else:
                            LOGGER.warning("Found more than one Stop command; ignoring all but the first one.")
                        continue
                    elif not script_table.do_loop:
                        continue  # Disregard all non-STOP entries after the first STOP

                    if cmd is not None:
                        msg_obj = self._parse_script_command(cmd, entry.get("params"))
                        msg_obj.delay_us = self._convert_frame_time(entry['delay'], entry['delay_unit'])
                        script_table.add_message(msg_obj)
                    else:
                        msg_objs = self._parse_script_frame(entry)
                        for msg_obj in msg_objs:
                            script_table.add_message(msg_obj)

                except (MbdfNodeNotFoundError, MbdfFrameNotFoundError) as exc:
                    LOGGER.error(str(exc))
                except ValueError as exc:
                    LOGGER.error("In script file: %s", str(exc))

            return script_table

        def fill_model_general(self, file_path):
            """ Fills up the general section of the model and stores the absolute path to the MBDF.

            Args:
                file_path (pathlib.Path): Path to the MBDF.
            """
            data = get_section(self.mbdf_data, 'General', required=True)
            input_speed = data['bus_speed'][0]
            if data['bus_speed'][1] == 'Mbps':
                exponent = 6
            else:
                exponent = 3
            bus_speed = int(input_speed * pow(10, exponent))
            self._mdl = MbdfModel(file_path, data['description_file'], data['bus_protocol_version'],
                                  data['bus_language_version'], bus_speed)

        def fill_model_broadcast_nodes(self):
            """ Generate broadcast "pseudo-node" objects. """
            for nad in range(0, 4):
                node = BroadcastNode(f"Broadcast{nad}", self._mdl)
                self._mdl.add_node(node)

        def fill_model_nodes(self):
            """ Fills up the nodes dict of the model with master node and placeholder slave node instances. """
            data = get_section(self.mbdf_data, 'Nodes', required=True)
            for node_type, sub in data.items():
                if node_type == 'Master':
                    master_obj = MasterNode(sub, self._mdl)
                    self._mdl.add_node(master_obj)
                elif node_type == 'Slaves':
                    for node in sub:
                        if node in self._mdl.nodes:
                            LOGGER.error("Nodes section: %s identifier must be unique and not reserved.", node)
                            continue
                        self._mdl.add_node(SlaveNode(node, self._mdl))

        def fill_model_node_attributes(self):
            """
            Overwrites placeholder SlaveNode instances in the nodes dict of the model with further instantiated slave
            node objects. An error gets logged when a duplicate configured NAD value is encountered.

            Raises:
                Error: Slave node is not defined in <Node_def>.
                Error: The bus protocol of a slave node is not supported.
                Error: The bus protocol of a slave is not supported by MBDF's bus protocol.
                Error: The configured NAD of the node is not unique in the Node_attributes section.
            """
            data = get_section(self.mbdf_data, 'Node_attributes')
            for name, node in data.items():
                if name not in self._mdl.slave_nodes:
                    LOGGER.error("Slave node '%s' not defined in <Node_def>!", name)

                sl_protocol = float(node['bus_protocol'])
                if sl_protocol not in SUPPORTED_PROTOCOLS:
                    LOGGER.error("Bus protocol %r of slave node %s is not supported by tool.", sl_protocol, name)
                elif sl_protocol > self._mdl.bus_protocol_version:
                    LOGGER.error("Bus protocol %r of slave node %s is not supported by MBDF's bus protocol %r.",
                                 sl_protocol, name, self._mdl.bus_protocol_version)
                ids = node['product_id']
                if len(ids) == 3:
                    product_id = SlaveNode.ProductId(ids[0], ids[1], ids[2])
                else:
                    product_id = SlaveNode.ProductId(ids[0], ids[1])

                # check for duplicate configured_nad values
                if node['configured_NAD'] in [node.configured_nad for node in self._mdl.slave_nodes.values()]:
                    LOGGER.error("The configured NAD %s of node %s is not unique in the Node_attributes section.",
                                 node['configured_NAD'], name)

                slave_node = SlaveNode(name, self._mdl)
                slave_node.bus_protocol = sl_protocol
                slave_node.configured_nad = node['configured_NAD']
                slave_node.product_id = product_id
                if node.get('P2_min') is not None:
                    slave_node.p2_min = node['P2_min']
                slave_node.m2s_ack = (node['M2S_ACK'] == 'True')
                self._mdl.add_node(slave_node)

                # All slave nodes listen to all broadcast NADs for now; in the future we may support
                # a broadcast_nads attribute.
                for broadcast_node in self._mdl.broadcast_nodes.values():
                    broadcast_node.add_listener(slave_node)

        def fill_model_signals(self):
            """ Adds general signals to the signals dict of the model. """
            data = get_section(self.mbdf_data, 'Signals', required=True)
            for name, signal in data.items():
                init_value_str = signal['init_value']
                size = signal['size']
                subscribers = signal['subscribed_by_list']

                signal_obj = Signal(name, size, int(init_value_str, base=0), self._mdl)
                if init_value_str.startswith('0x'):
                    signal_obj.value_repr = lambda x: "0x{:X}".format(x)
                elif init_value_str.startswith('0b'):
                    signal_obj.value_repr = bin

                for node_name in subscribers:
                    signal_obj.add_subscriber(self._mdl.nodes[node_name])
                self._mdl.add_signal(signal_obj)

        def _set_ext_instruction(self, frame_obj, instruction):
            try:
                frame_obj.ext_instruction = int(instruction)
            except ValueError:
                if instruction == 'NONE':
                    if isinstance(frame_obj, CommandFrameMelibu1):
                        raise MbdfError(f'Error in frame {frame_obj.name}: frame_instruction must not be "NONE" '
                                        f'when frame_function is "DATA"')
                else:
                    frame_obj.ext_instruction_signal = self._mdl.signals[instruction]

        def _set_instruction_word(self, frame_obj, instruction):
            try:
                frame_obj.instruction_word = int(instruction)
            except ValueError:
                if instruction == 'NONE':
                    raise MbdfError(f'Error in frame {frame_obj.name}: frame_instruction must not be "NONE" when '
                                    f'protocol version is {self._mdl.bus_protocol_version}')
                frame_obj.instruction_word_signal = self._mdl.signals[instruction]

        def _set_signal(self, frame_obj, sign_name, offset, partlogs):
            try:
                sign_obj = self._mdl.signals[sign_name]
            except KeyError:
                raise MbdfError(f'Signal name {sign_name} in frame {frame_obj.name} is missing from Signals section of '
                                f'MBDF')
            frame_obj.add_signal(sign_obj, offset, strict_hextet_packing='h' in partlogs)

        def _set_pl_length(self, frame_obj, pl_length):
            try:
                frame_obj.pl_length = int(pl_length)
            except ValueError as err:
                raise MbdfError(f'Error in frame {frame_obj.name}: expected an integer for frame_pl_length; '
                                f'got {pl_length}') from err

        def fill_model_frames(self, partlogs=""):  # noqa: C901
            """
            Adds frames to the frames dict of the model. Adds frame to supported_frames for every node that publishes or
            is subscribed to at least one signal in the frame.

            Raises:
                MbdfError: Bus protocol version does not support LED_EXTENDED mode
                MbdfError: frame_instruction may not be "NONE" (when frame_function is "DATA" and bus protocol_version <
                    2.0, or  when bus protocol_version >= 2.0)
                MbdfError: Signal name is missing from Signals section of MBDF
                MbdfError: Expected an integer for frame_pl_length
                MbdfError: Definition of frame is missing the <frame_i_select> parameter
            """
            data = get_section(self.mbdf_data, 'Frames', required=True)
            for name, frame in data.items():
                if self._mdl.bus_protocol_version < 2.0:
                    if frame['function_type'] == 'LED':
                        frame_obj = LedFrameMelibu1(self._mdl)
                    elif frame['function_type'] == 'LED_EXTENDED':
                        frame_obj = LedFrameMelibu1(self._mdl)
                        frame_obj.mode = LedFrameMelibu1.EXTENDED_MODE
                    else:
                        frame_obj = CommandFrameMelibu1(self._mdl)

                    sub_address = frame['subaddr_or_pl_length']
                    try:
                        frame_obj.sub_address = int(sub_address)
                    except ValueError:
                        frame_obj.sub_address_signal = self._mdl.signals[sub_address]
                    self._set_ext_instruction(frame_obj, frame['instruction'])
                else:
                    if frame['function_type'] == 'LED':
                        frame_obj = LedFrameMelibu2(self._mdl)
                    elif frame['function_type'] == 'LED_EXTENDED':
                        raise MbdfError(f"Bus protocol version {self._mdl.bus_protocol_version} does not support "
                                        "LED_EXTENDED mode")
                    else:
                        frame_obj = CommandFrameMelibu2(self._mdl)
                    self._set_pl_length(frame_obj, frame['subaddr_or_pl_length'])
                    try:
                        frame_obj.i_bit = int(frame['frame_i_select'] == 'True')
                    except KeyError:
                        raise MbdfError(f"Definition of frame {name!r} is missing a mandatory parameter")
                    self._set_instruction_word(frame_obj, frame['instruction'])
                frame_obj.name = name
                frame_obj.master_to_slave = (frame['direction'] == 'M2S')

                for sign_name, offset in frame['signals'].items():
                    self._set_signal(frame_obj, sign_name, offset, partlogs)
                self._mdl.add_frame(frame_obj)

        def fill_slave_nodes(self):
            """ Fills up the response_error and supported_frames members of the slave nodes. """
            data = get_section(self.mbdf_data, 'Node_attributes', required=True)
            for name, node in data.items():
                node_obj = self.get_node(name, 'Node_attributes section')

                resp_err = node['response_error']
                node_obj.response_error = self._mdl.signals[resp_err]

                for frame_name in node['supported_frames']:
                    node_obj.add_supported_frame(self._mdl.frames[frame_name])

        def fill_model_schedule_tables(self, filter_name=None):
            """ Fills up the schedule_tables dict of the model.

            Args
                filter_name (str/None): None takes into account all schedule tables; a schedule table name selects a
                    single one.
            """
            data = get_section(self.mbdf_data, 'Schedule_tables', required=True)
            for name, table in data.items():
                if filter_name is not None and filter_name != name:
                    continue
                sch_tbl = ScheduleTable(name, self._mdl)
                for entry in table:
                    try:
                        cmd = entry.get('cmd')
                        if cmd is not None:
                            msg_obj = self._parse_script_command(cmd, entry.get('params'))
                        else:
                            script_frame_class = ScriptFrameMelibu1 if self._mdl.bus_protocol_version < 2.0 \
                                                 else ScriptFrameMelibu2

                            node_name = entry['node_name']
                            if node_name == "Broadcast":
                                node_name = "Broadcast0"
                            node = self.get_node(node_name, f"{name} schedule", include_broadcast=True)
                            frame = self.get_frame(entry['frame_name'], f"{name} schedule")
                            msg_obj = script_frame_class(node, frame, model=self._mdl)

                        msg_obj.delay_us = self._convert_frame_time(entry['delay'], entry['delay_unit'])
                        sch_tbl.add_message(msg_obj, entry.get('label'))

                    except (MbdfNodeNotFoundError, MbdfFrameNotFoundError) as exc:
                        LOGGER.error(str(exc))
                    except ValueError as exc:
                        LOGGER.error("In %s schedule: %s", name, str(exc))

                try:
                    self._mdl.add_schedule_table(sch_tbl)
                except ValueError as exc:
                    raise MbdfError(f"Problem with schedule table {name}: {exc!s}")

        def fill_model_signal_representations(self, partlogs=""):
            """ Fills up the signal representations list of the model.

            Gets a list of encoding types from the function below.

            Args:
                partlogs (str): If character 's' is set, warnings about unused signal encoding types are suppressed.
            """
            enc_type_objs = self.fill_signal_encoding_types()
            data = get_section(self.mbdf_data, 'Signal_representation')
            representations = OrderedDict()
            for entry in data:
                enc_type_name = entry[0]
                signals = entry[1]
                if enc_type_name in representations:
                    representations[enc_type_name].extend(signals)
                else:
                    representations[enc_type_name] = signals
            for enc_type_name, signals in representations.items():
                enc_type_obj = enc_type_objs[enc_type_name]
                sig_rep_obj = SignalRepresentation(enc_type_obj)
                for name in signals:
                    try:
                        sign_obj = self._mdl.signals[name]
                    except KeyError:
                        raise MbdfError(f'Signal name {name} in encoding type {enc_type_name} is missing from Signals '
                                        f'section of MBDF')
                    sig_rep_obj.add_signal(sign_obj)
                self._mdl.add_signal_representation(sig_rep_obj)
            if "s" not in partlogs:
                for unused_encoding in set(enc_type_objs.keys()).difference(data.keys()):
                    LOGGER.warning(f"Signal encoding type {unused_encoding!r} is unused")

        def fill_signal_encoding_types(self):
            """ Creates and returns a list of all encoding types that exist in the parsed data.

            Returns:
                enc_type_objs (dict): Dictionary of all EncodingType instances that exist in the parsed data with
                    their name as key.
            """
            enc_type_objs = {}
            data = get_section(self.mbdf_data, 'Signal_encoding_types')
            for name, encodings in data.items():
                enc_type_obj = SignalEncodingType(name)
                for enc in encodings:
                    try:
                        if enc[0] == 'logical_value':
                            enc_obj = LogicalEncoding(enc['signal_value'], enc.get('text_info', ''))
                        elif enc[0] == 'physical_value':
                            enc_obj = PhysicalEncoding(enc['min_value'], enc['max_value'], enc['scale'],
                                                       enc['offset'], enc.get('text_info', ''))
                    except ValueError as err:
                        raise ValueError(f"Signal Encoding Type {name!r} - {err}") from err
                    enc_type_obj.add_encoding(enc_obj)
                enc_type_objs[name] = enc_type_obj
            return enc_type_objs

        def check_supported_frames(self, node_obj, used_node="", partlogs=""):
            """ If a slave node is subscribed to a signal, all frames containing this signal must exist in the
            slave's supported_frames list.
            A slave node must be subscribed to every signal of every frame in its supported_frames list, unless it's
            a S2M frame.

            Warns about nodes that are subscribed to a signal of a frame while this frame is not listed in its
            supported_frames list. If ``used_node`` is set, only the warnings relevant to this node are reported,
            unless ``partlogs`` contains 'u'.

            Reports an error when the bus protocol of the node is invalid based on the mode of a frame it supports.

            Args:
                node_obj (SlaveNode): Slave node for which to check its supported_frames attribute for completeness and
                    validity
                used_node (str): When set, warnings that are irrelevant to this slave node are disabled.
                partlogs (str): If character 'u' is set, warnings about nodes different from ``used_node``, are enabled.

            Raises:
                ERROR: Node supports M2S frame but it is not subscribed to any of its signals
                ERROR: Bus protocol of node is invalid based on a frame that it supports
            """
            node_name = node_obj.name
            frames_to_support = self.get_missing_frame_names(node_obj, used_node=used_node, partlogs=partlogs)
            missing_frames = natsorted(frames_to_support.difference(set(node_obj.supported_frames)))
            for missing_frame in missing_frames:
                if not used_node or node_name == used_node or "u" in partlogs:
                    LOGGER.warning(f"The supported_frames list of node {node_name!r} is missing frame "
                                   f"{missing_frame!r}. It is subscribed to at least one signal of this frame.")

            for frame in list(node_obj.supported_frames.values()):
                if frame.master_to_slave and frame.signals:
                    for signal, _ in frame.signals:
                        if node_obj in signal.subscribers:
                            break  # any missing subscriptions will have been reported in get_missing_frame_names
                    else:
                        LOGGER.error(f"Node {node_name!r} supports M2S frame {frame.name!r} but is not "
                                     f"subscribed to any of its signals")
            for frame in node_obj.supported_frames.values():
                if isinstance(frame, LedFrameMelibu1) and SUPPORTED_PROTOCOLS[node_obj.bus_protocol] != frame.mode:
                    exp = next((protocol for protocol, mode in SUPPORTED_PROTOCOLS.items() if mode == frame.mode), None)
                    LOGGER.error(f"Expected bus protocol of node {node_name!r} to be {exp} while processing frame "
                                 f"{frame.name!r}; got {node_obj.bus_protocol}")
                    break

        def get_missing_frame_names(self, node_obj, used_node="", partlogs=""):
            """ Returns the set of names of frames that are missing from the node's supported_frames list

            Warns about nodes that are only subscribed to some but not all signals of a frame. If ``used_node`` is set,
            only the warnings relevant to this node are reported, unless ``partlogs`` contains 'u'.

            Args:
                node_obj (SlaveNode): Slave node for which to check its supported_frames attribute for completeness and
                    validity
                used_node (str): When set, warnings that are irrelevant to this slave node are disabled.
                partlogs (str): If character 'u' is set, warnings about nodes different from ``used_node``, are enabled.

            Returns:
                set: Names of frames that are missing from the node's supported_frames list
            """
            subscribed_signals = []
            for name, signal in self._mdl.signals.items():
                if node_obj in signal.subscribers:
                    subscribed_signals.append(name)
            frames_to_support = set()
            for name, frame in self._mdl.frames.items():
                to_support = 0
                for signal, _ in frame.signals:
                    if signal.name in subscribed_signals:
                        to_support += 1
                        frames_to_support.add(name)
                if to_support and to_support != len(frame.signals) and \
                   (not used_node or node_obj.name == used_node or "u" in partlogs):
                    LOGGER.warning(f"Node {node_obj.name!r} is only subscribed to {to_support} out of "
                                   f"{len(frame.signals)} signals of frame {name!r}; expected subscription to all")
            return frames_to_support

        def validate_script_frame_entries(self):
            """
            Validates ScriptFrameBase objects in schedule tables by checking if their frame exist
            in the supported_frames attribute of the receiving or sending slave node.

            Raises:
                ERROR: Schedule table schedules frame with node as sender/receiver but the frame is missing from the
                    node's supported_frames list.
            """
            for table in self._mdl.schedule_tables.values():
                for message in table.messages:
                    # filter out ScriptFrameBase without "Broadcast"
                    if isinstance(message, ScriptFrameBase) and isinstance(message.node, SlaveNode):
                        node = message.node
                        frame = message.frame
                        if frame.name not in node.supported_frames:
                            LOGGER.error(f"Schedule table {table.name!r} schedules frame {frame.name!r} "
                                         f"with node {node.name!r} as sender/receiver but the frame is missing from "
                                         f"the node's supported_frames list.")

        def verify_s2m_signal_subscription(self):
            """ Verifies the subscribers list of signals that exists in a S2M frame

            Raises:
                ERROR: Signal exists in a S2M frame and, therefore, the master node must be the sole node in its list
                    of subscribers
            """
            verified_signals = set()
            for frame in self._mdl.frames.values():
                if frame.master_to_slave:
                    continue
                for signal, _ in frame.signals:
                    if signal.name in verified_signals:
                        continue
                    if len(signal.subscribers) != 1 or signal.subscribers[0].TYPE != "MASTER":
                        LOGGER.error(f"Signal {signal.name!r} exists in a S2M frame and, therefore, the master "
                                     f"node must be the sole node in its list of subscribers")
                    verified_signals.add(signal.name)

        def _parse_script_command(self, cmd, args):
            """ Parses a schedule table entry with a command and parameters.

            Args:
                cmd (str): Command name
                args (list): Arguments to the command

            Returns:
                ScriptWakeupFrame, ScriptAutoaddressFrame,
                PowerSupply, DigitalOutput, or None (if no command matched).
            """
            broadcast_min_resp_time, start_address, node_count = self._get_schedule_parameters()

            if cmd == "Wakeup":
                msg_obj = ScriptWakeupFrame(self._mdl)
            elif cmd in ("AutoAddress", "AutoAddressSaveNad"):
                msg_obj = ScriptAutoaddressFrame(self._mdl)
                msg_obj.save_nad = cmd.endswith("SaveNad")
                msg_obj.startaddress = start_address
                msg_obj.node_count = node_count
            elif cmd == 'PowerSupply':
                state = self._on_off_to_int(args['state'])
                msg_obj = PowerSupply(state, self._mdl)
            elif cmd in ('DigOutput', 'DigInput'):
                number = int(args['nr'])
                if cmd == 'DigOutput':
                    state = self._on_off_to_int(args['state'])
                    msg_obj = DigitalOutput(number, state, self._mdl)
                elif cmd == 'DigInput':
                    msg_obj = DigitalInput(number, self._mdl)
            elif cmd == 'SetBaudrate':
                if args['speed'] == "default":
                    msg_obj = SetBaudrate(None, self._mdl)
                elif args['speed_unit'] == 'Mbps':
                    msg_obj = SetBaudrate(int(args['speed'] * 10**6), self._mdl)
                else:
                    msg_obj = SetBaudrate(int(args['speed'] * 10**3), self._mdl)
            elif cmd == 'ExecuteScript':
                msg_obj = ExecuteScript(Path(args['path']), self._mdl)
            else:
                return None

            msg_obj.min_response_time_ms = broadcast_min_resp_time

            return msg_obj

        @staticmethod
        def _convert_frame_time(time, unit):
            """ Converts the time in given unit to a float in microseconds.

            Args:
                time (int): Input time in given unit.
                unit (str): Unit: either s, ms or us.

            Returns:
                int: Input time in microseconds.
            """
            factors = {
                'us': 1,
                'ms': pow(10, 3),
                's': pow(10, 6),
            }
            return int(time * factors[unit])

        @staticmethod
        def _on_off_to_int(value):
            if value == 'ON':
                return 1
            elif value == 'OFF':
                return 0
            raise ValueError(f"Expected 'ON' or 'OFF'; got {value}")

        def get_node(self, name, section, include_broadcast=False):
            """ Gets and returns the node instance from the model or raise an error when not found.

            Args:
                name (str): Node name specified in MBDF-file.
                section (str): MBDF section to refer to in the error message
                include_broadcast (bool): Broadcast nodes will not be filtered out if this is True.

            Raises:
                MbdfError: Node has the wrong type.
                MbdfNodeNotFoundError: Node could not be found in the node definition set.

            Returns:
                SlaveNode: Slave (or broadcast) node
            """
            type_ = "slave"
            if include_broadcast:
                type_ += " or broadcast"

            node = self._mdl.nodes.get(name)
            if node:
                if node.TYPE == "MASTER":
                    raise MbdfError(f"Expected {type_} node in {section}, but {name!r} is the master.")
                if node.TYPE == "BROADCAST" and not include_broadcast:
                    raise MbdfError(f"Node name {name!r} is not allowed in {section}.")
                return node
            raise MbdfNodeNotFoundError(f"Could not find {type_} node {name!r} used in {section}.")

        def get_frame(self, name, section):
            """ Gets and returns the frame instance from the model or raise an error when not found.

            Args:
                name (str): Frame name
                section (str): MBDF section to refer to in the error message

            Raises:
                MbdfFrameNotFoundError: Frame could not be found in the frame definition set.
            """
            try:
                return self._mdl.frames[name]
            except KeyError:
                raise MbdfFrameNotFoundError(f"Could not find frame '{name}' used in {section}.") from None

        def _get_schedule_parameters(self):
            """  Gets the paremeters needed for broadcast script frames.

            Returns:
                int: The minimum time in ms which is needed by the slave to respond; minimum is 5 ms.
                int: The lowest NAD among all slave nodes in the cluster.
                int: The amount of slave nodes in the cluster.
            """
            broadcast_min_resp_time = max(self._mdl.slave_nodes.values(), key=attrgetter('p2_min')).p2_min
            start_address = min(self._mdl.slave_nodes.values(), key=attrgetter('configured_nad')).configured_nad
            return broadcast_min_resp_time, start_address, len(self._mdl.slave_nodes)


def get_section(mbdf_data, section_name, required=False):
    """
    Gets and returns the specified section from the parsed data. It raises an error when the section is non-existent
    and the required parameter is set to True. An empty dict is returned when the section is optional and non-existent.

    Args:
        mbdf_data (ParseResults): Output data of reader.
        section_name (str): Specifies the section name, as defined by the reader.
        required (bool): Indicates whether the section is required by the MBDF specification or not.

    Raises:
        MbdfError: When a section that is required is missing.

    Returns:
        Object: The specified section of the reader's output.
    """
    data = mbdf_data.get(section_name)
    if data is not None:
        return data
    if required and data is None:
        raise MbdfError("Required section %s is missing in parsed data." % section_name)
    return {}
