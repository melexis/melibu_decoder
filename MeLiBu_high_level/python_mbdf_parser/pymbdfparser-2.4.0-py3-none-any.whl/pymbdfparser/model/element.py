""" Module for the MbdfElement class """
import weakref
from abc import ABC
from pymbdfparser.exceptions import MbdfMissingModelError


class MbdfElement(ABC):
    """ Class representing a (child) element of the MbdfModel. """

    def __init__(self, *args, model=None, **kwargs):
        """ Constructor of the MbdfElement class.

        Args:
            model (MbdfModel):          Parent model that contains this element.
        """
        super().__init__(*args, **kwargs)
        if model is not None:
            self._mdl_ref = weakref.ref(model)
        else:
            self._mdl_ref = None

    @property
    def model(self):
        """ MbdfModel: Parent MbdfModel if it exists.

        Raises:
            MbdfMissingModelError: the element was never attached to a parent model,
            or the parent model has gone out of scope and was garbage collected.
        """
        if self._mdl_ref is None:
            raise MbdfMissingModelError(f"{self!s} was initialized without a parent model.")
        if self._mdl_ref() is None:
            raise MbdfMissingModelError(f"{self!s} cannot access the parent model; has it been deleted?")
        return self._mdl_ref()
