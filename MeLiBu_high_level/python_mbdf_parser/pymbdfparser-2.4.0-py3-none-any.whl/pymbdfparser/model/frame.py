""" Module for the Frame class and its subclasses """
import logging
from abc import ABC

from pymelibuframe import (Melibu2CommandFrame, Melibu2Frame, Melibu2LedFrame,
                           Melibu1CommandFrame, Melibu1Frame, Melibu1LedFrame)

from pymbdfparser.model.exceptions import MbdfModelException
from pymbdfparser.model.frame_base import FrameBase
from pymbdfparser.model.signal_chunk import OffsetSignalMelibu1, OffsetSignalMelibu2

LOGGER = logging.getLogger('pymbdfparser')


class FrameMelibu1(FrameBase, Melibu1Frame, ABC):  # pylint: disable=abstract-method
    """ Melibu 1.x standard frame class """

    bitorder = 'big'
    byteorder = 'big'
    wordorder = 'little'
    offset_signal_class = OffsetSignalMelibu1

    def __init__(self, model=None):
        """ Constructor of the FrameMelibu1 class.

        Args:
            model (MbdfModel): Parent model that contains this frame.
        """
        super().__init__(model=model)
        self._sub_addr_signal = None

    @property
    def sub_address(self):
        """ int: the sub address for this frame as an integer value """
        if self.sub_address_signal:
            return self.sub_address_signal.bus_value & self.MAX_SUB_INSTR
        return self._sub_addr

    @sub_address.setter
    def sub_address(self, value):
        self._sub_addr = value & self.MAX_SUB_INSTR
        if self._sub_addr_signal:
            self._sub_addr_signal.bus_value = value

    @property
    def sub_address_signal(self):
        """ Signal/None: Signal that holds the sub address for this frame """
        return self._sub_addr_signal

    @sub_address_signal.setter
    def sub_address_signal(self, signal):
        self._sub_addr_signal = signal
        self._sub_addr = signal.bus_value & self.MAX_SUB_INSTR

    def add_signal(self, signal, offset, strict_hextet_packing=False):  # pylint: disable=arguments-differ
        """ Adds a namedtuple OffsetSignalMelibu1 to the signals list.

        Args:
            signal (Signal): Signal instance to be added to the signals list.
            offset (int): Offset of the signal to be added to the signals list.
                The offset starts at the LSBit of Dataword[0] and gets incremented till the MSBit of the Word
                (offset = 15). After reaching the MSBit of the Dataword[0], the offset gets incremented again, starting
                at the LSBit of Dataword[1] et cetera.
            strict_hextet_packing (bool): True to raise an exception or False to log a warning when there is a risk
                of a signal being partially transmitted because it does not fit in a single six-byte payload section
                and the sub-address is being used as a mask to determine which six-byte sections are transmitted.

        Raises:
            TypeError: The type of the passed signal argument is wrong.
            ValueError: The value of offset and/or signal.size is/are wrong.
            ValueError: Frame uses its subaddress as a payload mask; signal should fit within a six-byte section.
        """
        super().add_signal(signal, offset)
        if self.sub_address_signal and int(offset / 48) != int((offset + signal.size - 1) / 48):
            msg = ("Frame %s uses its subaddress as a payload mask; signal %s should fit within a six-byte section."
                   % (self.name, signal.name))
            if strict_hextet_packing:
                raise ValueError(msg)

            LOGGER.warning(msg)


class LedFrameMelibu1 (FrameMelibu1, Melibu1LedFrame):
    """ Melibu 1.x LED Frame class """

    @property
    def max_size(self):
        """ int: maximum logical payload size in bytes, accounting for piecewise frame
                 transmission using sub_address as a color vector mask """
        if not self.sub_address_signal:
            return self.size
        if self.mode == self.EXTENDED_MODE:
            return 128
        return 36

    def transmit_pre_process(self, node, signal_values=(), sub_address=None):
        if sub_address is not None:
            if self.sub_address_signal is None:
                raise MbdfModelException(f"Cannot change subaddress of frame {self.name} as it does not have a "
                                         "sub_address_signal.")
            self.sub_address = sub_address

        super().transmit_pre_process(node, signal_values)


class CommandFrameMelibu1(FrameMelibu1, Melibu1CommandFrame):
    """ Melibu 1.x Command Frame class """

    def __init__(self, model=None):
        """ Constructor of the CommandFrameMelibu1 class.

        Args:
            model (MbdfModel): Parent model that contains this frame
        """
        super().__init__(model=model)
        self._ext_instr_signal = None

    @property
    def max_size(self):
        """ int: maximum logical payload size in bytes, accounting for piecewise frame
                 transmission using sub_address as a color vector mask """
        if not self.sub_address_signal:
            return self.size
        return 18

    @property
    def ext_instruction(self):
        """ int: the ext instruction for this frame as an integer value """
        if self.ext_instruction_signal:
            return self.ext_instruction_signal.bus_value & self.MAX_SUB_INSTR
        return self._ext_instr

    @ext_instruction.setter
    def ext_instruction(self, value):
        self._ext_instr = value & self.MAX_SUB_INSTR
        if self._ext_instr_signal:
            self._ext_instr_signal.bus_value = value

    @property
    def ext_instruction_signal(self):
        """ Signal/None: Signal that holds the ext instruction for this frame """
        return self._ext_instr_signal

    @ext_instruction_signal.setter
    def ext_instruction_signal(self, signal):
        self._ext_instr_signal = signal
        self._ext_instr = signal.bus_value & self.MAX_SUB_INSTR

    def transmit_pre_process(self, node, signal_values=(), sub_address=None, ext_instruction=None):
        if sub_address is not None:
            if self.sub_address_signal is None:
                raise MbdfModelException(f"Cannot change subaddress of frame {self.name} as it does not have a "
                                         "sub_address_signal.")
            self.sub_address = sub_address
        if ext_instruction is not None:
            if self.ext_instruction_signal is None:
                raise MbdfModelException(f"Cannot change ext-instruction of frame {self.name} as it does not have an "
                                         "ext_instruction_signal.")
            self.ext_instruction = ext_instruction

        super().transmit_pre_process(node, signal_values)


class FrameMelibu2(FrameBase, Melibu2Frame, ABC):  # pylint: disable=abstract-method
    """ Melibu 2.x standard frame class """

    bitorder = 'little'
    byteorder = 'little'
    wordorder = 'little'
    offset_signal_class = OffsetSignalMelibu2

    def __init__(self, model=None):
        """ Constructor of the FrameMelibu2 class.

        Args:
            model (MbdfModel): Parent model that contains this frame.
        """
        super().__init__(model=model)
        self._instruction_word_signal = None

    @property
    def instruction_word(self):
        """ int: the instruction word for this frame """
        if self.instruction_word_signal:
            return self.instruction_word_signal.bus_value & self.MAX_INSTR_WORD
        return self._instruction_word

    @instruction_word.setter
    def instruction_word(self, value):
        super(FrameMelibu2, self.__class__).instruction_word.fset(self, value)
        if self._instruction_word_signal:
            self._instruction_word_signal.bus_value = self._instruction_word

    @property
    def instruction_word_signal(self):
        """ Signal/None: Signal that holds the instruction word for this frame """
        return self._instruction_word_signal

    @instruction_word_signal.setter
    def instruction_word_signal(self, signal):
        self._instruction_word_signal = signal
        self._instruction_word = signal.bus_value & self.MAX_INSTR_WORD

    @property
    def max_size(self):
        """ int: maximum logical payload size in bytes  """
        return self.size

    def transmit_pre_process(self, node, signal_values=(), instruction_word=None):
        if instruction_word is not None:
            if self.instruction_word_signal is None:
                raise MbdfModelException(f"Cannot change instruction word of frame {self.name} as it does not have an "
                                         "instruction_word_signal.")
            self.instruction_word = instruction_word

        super().transmit_pre_process(node, signal_values)


class LedFrameMelibu2(FrameMelibu2, Melibu2LedFrame):
    """ Melibu 2.x LED Frame class """


class CommandFrameMelibu2(FrameMelibu2, Melibu2CommandFrame):
    """ Melibu 2.x Command Frame class """
