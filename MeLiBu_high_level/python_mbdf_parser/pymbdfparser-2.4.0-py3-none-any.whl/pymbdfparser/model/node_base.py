""" Module for the Node class """
from abc import ABC

from pymbdfparser.model.element import MbdfElement


class Node(MbdfElement, ABC):
    """ Abstract class for defining all participating nodes in the cluster.

    Defines all participating nodes in the cluster. The definitions in this class create a node identifier set.
    All identifiers in this set shall be unique. Each node is also given an index.
    """
    TYPE = None

    def __init__(self, name, model=None):
        """ Constructor of the Node class.

        Args:
            name (str):                 The name of the node, which is unique in the cluster.
        """
        super().__init__(model=model)
        self._name = ""
        self.name = name
        self.all_frames = {}
        self.all_signals = []

    def __eq__(self, other):
        """ Tests two objects for equality based on attribute values.

        Args:
            other (Node):               Node instance
        Returns:
            Whether both dict attributes and object types are equal or not.
        """
        if type(other) is type(self):
            if self is other:
                return True
            return self.__dict__ == other.__dict__
        return False

    @property
    def name(self):
        """ Gets the node name."""
        return self._name

    @name.setter
    def name(self, name):
        self._name = name
