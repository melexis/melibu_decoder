""" Module for the ScriptFrame class """

from abc import ABC, abstractmethod

from pymelibuframe import MelibuFrameException

from pymbdfparser.exceptions import MbdfError
from pymbdfparser.model.node import BroadcastNode
from pymbdfparser.model.script_base import ScriptBase


class ScriptFrameBase(ScriptBase, ABC):
    """ Base class for ScriptFrames """

    def __init__(self, node, frame, model=None):
        """ Constructor of the ScriptFrameBase class """
        super().__init__(model=model)
        self._node = None
        self.node = node
        self._frame = None
        self.frame = frame
        self._signal_values = []

    def __str__(self):
        return (f"Melibu Script {self.script_type} with frame content: {self.frame}, "
                f"delay[us]: {self.delay_us}, min_resp_time: {self.min_response_time_ms}")

    @property
    def node(self):
        """ SlaveNode: Slave or broadcast node that sends or receives the message """
        return self._node

    @node.setter
    def node(self, node_obj):
        self._node = node_obj

    @property
    def frame(self):
        """ FrameBase: the MeLiBu frame structure to be transmitted/received """
        return self._frame

    @frame.setter
    def frame(self, frame):
        if frame is None:
            self._frame = None
            return
        if self.node is None:
            raise AttributeError("Cannot set the frame to send without a node to check against.")
        if frame not in self.node.supported_frames.values():
            raise ValueError(f"Node {self.node.name} does not support frame {frame.name}.")

        self._frame = frame

    @property
    def signal_values(self):
        """ list: Signal values to set before transmitting the frame, in the
        order of their appearance in the underlying Frame. """
        return self._signal_values

    @signal_values.setter
    def signal_values(self, signal_values):
        if signal_values and len(signal_values) != len(self.frame.unsorted_signals):
            raise ValueError(f"Expected exactly {len(self.frame.unsorted_signals)} signal values for frame "
                             f"{self.frame.name}; got {len(signal_values)}.")
        if not self.frame.master_to_slave and signal_values:
            raise MbdfError(f"Expected <frame_data> to be empty for frame {self.frame.name} as it is S2M; "
                            f"got {signal_values}")

        self._signal_values = signal_values

    @property
    def broadcast(self):
        """ bool: True in case of a broadcast frame, False otherwise. """
        return isinstance(self.node, BroadcastNode)

    @property
    def min_response_time_ms(self):
        """ int: the minimum time in ms which is needed by the slave to respond """
        return self.node.p2_min

    @abstractmethod
    def buffer_frame_attribute_signals(self):
        """ Stores the initial value of all signals that determine a frame attribute (apart from the payload)

        This shall only be done for objects that are part of a ScriptTable, not a ScheduleTable.
        """

    @abstractmethod
    def transmit_pre_process(self):
        """ Prepare the underlying frame for transmission and return it. """


class ScriptFrameMelibu1(ScriptFrameBase):
    """ Class for defining a message that specifies and transfers a MeLiBu 1.x Frame."""

    _script_type = "Frame"

    def __init__(self, node, frame, model=None):
        """ Constructor of the ScriptFrameMelibu1 class """
        super().__init__(node, frame, model=model)
        self._sub_addr = None
        self._ext_instr = None

    @property
    def sub_address(self):
        """ int: Value to assign to the subaddress signal before transmitting the frame """
        return self._sub_addr

    @sub_address.setter
    def sub_address(self, sub_address):
        if self.frame.sub_address_signal is None:
            if sub_address == self.frame.sub_address or sub_address is None:
                # Do not enforce (sub_address is None) because MBDF Script Converter
                # generated scripts with sub_address = 0x3f even when there was no
                # need to override it.
                return
            raise MbdfError(f"Cannot change script frame subaddress, as underlying frame "
                            f"{self.frame.name} does not have a sub_address_signal.")

        self._sub_addr = sub_address

    @property
    def ext_instruction(self):
        """ int: Value to assign to the ext-instruction signal before transmitting the frame;
        None if the default should be used. """
        return self._ext_instr

    @ext_instruction.setter
    def ext_instruction(self, ext_instruction):
        if self.frame.function_type != "Command":
            if not ext_instruction:
                # Allow ext_instruction == 0x00 because MBDF Script Converter
                # generated scripts like this for LED frames.
                # Strictly speaking, only None should be allowed.
                return

            raise MbdfError(f"Cannot set script frame ext_instruction because the underlying frame "
                            f"({self.frame.name}) is not a CommandFrame.")

        if self.frame.ext_instruction_signal is None:
            if ext_instruction == self.frame.ext_instruction or ext_instruction is None:
                # Do not enforce (ext_instruction is None) if the user is not attempting
                # to override it.
                return

            raise MbdfError(f"Cannot change script frame ext_instruction because the underlying frame "
                            f"({self.frame.name}) does not have an ext_instruction_signal.")

        self._ext_instr = ext_instruction

    def buffer_frame_attribute_signals(self):
        """ Stores the initial value of the frame's sub_address and ext_instruction if it is determined by a signal """
        try:
            self.sub_address = self.frame.sub_address
        except MbdfError:
            pass  # No need to save the initial sub_address
        try:
            self.ext_instruction = self.frame.ext_instruction
        except (MbdfError, MelibuFrameException):
            pass  # No need to save the initial ext_instruction

    def transmit_pre_process(self):
        """ Prepare the underlying frame for sending.

        Note: calling this function will have side effects if transmit_pre_process
        has side effects (like changing the signal values).
        """
        if self.frame.function_type == "Command":
            self.frame.transmit_pre_process(self.node, self.signal_values, self.sub_address, self.ext_instruction)
        else:
            self.frame.transmit_pre_process(self.node, self.signal_values, self.sub_address)


class ScriptFrameMelibu2(ScriptFrameBase):
    """ Class for defining a message that transfers a MeLiBu 2.0 Frame """

    _script_type = "Frame2"

    def __init__(self, node, frame, model=None):
        """ Constructor of the ScriptFrameMelibu2 class """
        super().__init__(node, frame, model=model)
        self._instruction_word = None

    @property
    def instruction_word(self):
        """ int: Value to assign to the instruction word signal before transmitting the frame """
        return self._instruction_word

    @instruction_word.setter
    def instruction_word(self, instruction_word):
        if instruction_word is not None:
            if not self.frame.instruction_word_signal:
                raise MbdfError(f"Cannot set script frame instruction word because the underlying frame "
                                f"({self.frame.name}) does not have an instruction_word_signal.")
            if self.frame.i_bit == 0:
                raise MbdfError(f"Cannot set script frame instruction word because the underlying frame "
                                f"({self.frame.name}) has its Instruction Word Select bit set to 0.")
        self._instruction_word = instruction_word

    def buffer_frame_attribute_signals(self):
        """ Stores the initial value of the frame's instruction_word if it is determined by a signal """
        try:
            self.instruction_word = self.frame.instruction_word
        except MbdfError:
            pass  # No need to save the initial instruction_word

    def transmit_pre_process(self):
        """ Prepare the underlying frame for sending.

        Note: calling this function will have side effects if transmit_pre_process
        has side effects (like changing the signal values).
        """
        return self.frame.transmit_pre_process(self.node,
                                               self.signal_values,
                                               self.instruction_word)
