""" Module for the ScheduleTable class """
import logging
from weakref import ref

from pymbdfparser.model.element import MbdfElement
from pymbdfparser.model.exceptions import MbdfModelException
from pymbdfparser.model.script_base import ScriptBase

LOGGER = logging.getLogger('pymbdfparser')


class ScheduleTable(MbdfElement):
    """ Class for describing the frames and the timing of the frames transmitted on the bus.

    Attributes:
        name (str): Unique name of the schedule table.
        messages (list): The messages specify what will be done in the frame slot.
        labels (dict): Keys are named positions in the table; values are indices in the messages list.
            The labels "start" and "loop" are special, always available and mapped to index 0 by default.
        do_loop (bool): True for a continuous loop; False otherwise.
    """

    SCHEDULE_STOPPED = 0
    SCHEDULE_JUMPING = 1
    SCHEDULE_LOOP = 2

    class Labels(dict):
        """ Helper class providing a bidirectional map between label strings and indices in
        a schedule table. """

        def __init__(self, table):
            super().__init__()
            self._table = ref(table)

        def __missing__(self, key):
            """ Return index for a special label (i.e. start or loop), or a label for an index.

            Raises:
                KeyError: label does not exist in the table.
            """
            if key in ("start", "loop"):
                return 0
            for name, index in self.items():
                if key is index:
                    return name
            raise KeyError(f"Label or index {key!r} does not exist in table {self._table().name!r}.")

        def __setitem__(self, label, index):
            """ Adds the label at the given index.

            Raises:
                TypeError: Label is not a string or index not an int
                IndexError: Index is out of range for the schedule table
                ValueError: Nonzero index assigned to the "start" label.
            """
            if not isinstance(label, str):
                raise TypeError(f"Label names must be strings; got {label.__class__.__name__}.")
            if not isinstance(index, int):
                raise TypeError(f"Labels must point to integer indices; got {index.__class__.__name__}.")
            if index < 0 or index >= len(self._table().messages):
                raise IndexError(f"Index {index!r} out of range for table {self._table().name}; "
                                 f"cannot add a label there.")
            if label == "start" and index != 0:
                raise ValueError(f"The :start: label must always point index 0, i.e. the first entry in the schedule "
                                 f"table; got {index!r}")
            super().__setitem__(label, index)

        def __delitem__(self, key):
            """ Delete a label, or the label at an index. """
            if isinstance(key, int):
                key = self[key]
            super().__delitem__(key)

        def __contains__(self, item):
            """ Returns true if item is a label string or an index that has a label. """
            return super().__contains__(item) or item in self.values()

        def __ior__(self, other):
            """ Add all labels from other, overwriting existing labels. """
            for key, value in other.items():
                self[key] = value

        def __or__(self, other):
            return NotImplemented

        def __ror__(self, other):
            return NotImplemented

        def get(self, key, default=None):
            """ Return index for a label, or label for an index, or default if neither label nor index exist.
            Equivalent to dict.get(), but uses overridden __getitem__(). """
            try:
                return self[key]
            except KeyError:
                return default

    def __init__(self, name, model=None):
        """ Constructor of the ScheduleTable class.

        Args:
            name (str):                 Unique name of the schedule table.
            model (MbdfModel):          Parent model that contains this schedule table
        """
        super().__init__(model=model)
        self._name = name
        self._messages = []
        self._schedule_state = self.SCHEDULE_STOPPED
        self._current_index = 0
        self._jump_target = 0
        self.do_loop = True
        self.labels = self.Labels(self)

    def __eq__(self, other):
        """ Tests two objects for equality based on attribute values.

        Args:
            other (ScheduleTable): ScheduleTable instance
        Returns:
            bool: Whether both dict attributes and object types are equal or not.
        """
        if type(other) is type(self):
            return self.__dict__ == other.__dict__
        return False

    def __iter__(self):
        """ Return an iterator for the messages in the schedule table. Since only
        one iterator is allowed at a time, the schedule table is an iterator itself.
        Thus, this function just returns self. """

        return self

    def __next__(self):
        """ Iterate on the schedule table.

        Returns:
            tuple(int, ScriptBase): Current message index and message object.

        Raises:
            StopIteration: exit_schedule() was called or the last message was already processed and continuous looping
                is disabled.
            MbdfModelException: Iteration failed due to an unexpected schedule state
        """
        if self._schedule_state == self.SCHEDULE_STOPPED:
            raise StopIteration()

        if self._schedule_state == self.SCHEDULE_JUMPING:
            while self.current_index != self._jump_target:
                self._increment()

            self._schedule_state = self.SCHEDULE_LOOP
            return self.current_index, self.current_message

        if self._schedule_state == self.SCHEDULE_LOOP:
            self._increment()
            if not self.do_loop and self.current_index == len(self.messages) - 1:
                self.exit_schedule()
            return self.current_index, self.current_message

        raise MbdfModelException(f"Failed to iterate on schedule table {self.name!r} as it has reached an unexpected "
                                 f"state: {self._schedule_state}")

    @property
    def name(self):
        """ Gets the name."""
        return self._name

    @property
    def messages(self):
        """ Gets the list of messages."""
        return self._messages  # Do not sort!

    def add_message(self, message, label=None):
        """ Adds a message to the list of messages.

        Args:
            message (ScriptBase): ScriptBase subclass object be added to the list of messages.
            label (str): Label to assign to this message's position in the table.

        Raises:
            TypeError: Type must be ScriptBase; label type must be str (or NoneType)
            ValueError: Label is already in use
        """
        if not isinstance(message, ScriptBase):
            raise TypeError("Type must be ScriptBase; got %s" % message.__class__.__name__)
        self._messages.append(message)

        if label is not None:
            if label in self.labels:
                raise ValueError(f"Label {label!r} is already in use.")
            self.labels[label] = len(self.messages) - 1

    def replace(self, message, messages):
        """ Replaces a message by a list of messages.

        Note: some indices in `self.labels` may need to be increased if more than one message was added as replacement.

        Args:
            message (ScriptBase): The message to be substituted, e.g. ExecuteScript instance.
            messages (list[ScriptBase]): List of messages to replace a message on its location.
        """
        index = self.messages.index(message)
        self.messages.pop(index)
        self.messages[index:index] = messages
        for label, label_index in self.labels.items():
            if label_index > index:
                self.labels[label] += len(messages) - 1

    @property
    def current_index(self):
        """ int: Current message index """
        return self._current_index

    @property
    def current_message(self):
        """ ScriptBase: Current message """
        return self.messages[self.current_index]

    @property
    def current_label(self):
        """ str: Label corresponding to current_index; None if there is no label at
        the current index. """
        return self.labels.get(self.current_index)

    def enter_schedule(self, index=0):
        """ Prepare for iteration; reset the message index counter.

        Args:
            index (int): Message index to jump to upon entering the schedule
        """
        if len(self.messages) == 0:
            # Stay in SCHEDULE_STOPPED state; nothing to do
            return

        self._current_index = self.labels["start"] - 1
        self._schedule_state = self.SCHEDULE_LOOP
        self.jump_to(index)

    def exit_schedule(self):
        """ Prevent further iteration on this schedule. """

        self._schedule_state = self.SCHEDULE_STOPPED

    def jump_to(self, index):
        """ Initiate a jump to the given message index.

        Raises:
            ValueError: Jump target is outside of the schedule.
        """

        if index < 0 or index >= len(self.messages):
            raise ValueError(f"Jump target is out of range; got {index!r}.")
        if index == self.current_index + 1:
            # Jump target is the next index; nothing to do
            return
        self._jump_target = index
        self._schedule_state = self.SCHEDULE_JUMPING

    def _increment(self):
        """ Increment the message index counter """
        if (self._current_index + 1) < len(self.messages):
            self._current_index += 1
        else:
            self._current_index = self.labels["loop"]


class ScriptTable(ScheduleTable):
    """ Class for describing the frames in a script file and the timing of the frames transmitted on the bus.

    Attributes:
        required_mbdf (str): The filename of the corresponding MBDF.
        model (MbdfModel): Parent model that contains this ScriptTable
    """
    strict_filename_checking = True

    def __init__(self, name, required_mbdf, model=None):
        """ Constructor of the ScriptTable class.

        Args:
            name (str): Name of the script table.
            required_mbdf (str): The filename of the corresponding MBDF.
        """
        super().__init__(name, model=model)
        self._required_mbdf = ""
        self.required_mbdf = required_mbdf

    @property
    def required_mbdf(self):
        """ Gets the filename of the corresponding MBDF."""
        return self._required_mbdf

    @required_mbdf.setter
    def required_mbdf(self, value):
        if value != self.model.mbdf_filename:
            msg = (f"MBDF filename in script file does not match the input MBDF filename; got {value!r} instead of "
                   f"{self.model.mbdf_filename!r}")
            if self.strict_filename_checking:
                raise ValueError(msg)
            else:
                LOGGER.warning(msg)

        self._required_mbdf = value
