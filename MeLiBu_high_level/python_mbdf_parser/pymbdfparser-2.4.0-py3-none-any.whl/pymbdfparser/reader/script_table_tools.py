""" Parser expressions for script and schedule tables """
from pyparsing import CharsNotIn, Group, Optional, Suppress
from pymbdfparser.reader.reader_tools import (_C_, _CL_, Reserved, block, intx, parse_bus_speed, parse_id)


def cmd(name):
    """ Script/schedule table command """
    return Reserved(name).setResultsName("cmd")


def params(expr):
    """ Group and label script/schedule table command parameters """
    return Group(expr).setResultsName("params")


def entry_label():
    """ Syntax for :labels: in the script/schedule table """
    return Optional(_CL_ + parse_id("label") + _CL_)


def script_command():
    """ Syntax for all supported script commands """
    return (cmd("AutoAddressSaveNad")) |\
           (cmd("AutoAddress")) |\
           (cmd("DigInput") + params(block(intx("nr")))) |\
           (cmd("DigOutput") + params(block(intx("nr") + _C_ +
                                            (Reserved("ON").setResultsName("state") |
                                             Reserved("OFF").setResultsName("state"))))) |\
           (cmd("PowerSupply") + params(block(Reserved("ON").setResultsName("state") |
                                              Reserved("OFF").setResultsName("state")))) |\
           (cmd("Wakeup")) |\
           (cmd("SetBaudrate") + params(block(Reserved("default").setResultsName("speed") | parse_bus_speed()))) |\
           (cmd("ExecuteScript") + params(block(CharsNotIn('{}').setResultsName("path"))))


def delay():
    "delay integer s|ms|us"
    return Suppress("delay") + intx("delay") +\
        (Reserved('us') | Reserved('ms') | Reserved('s')).setResultsName("delay_unit")
