from abc import ABC, abstractmethod


class Reader(ABC):
    @abstractmethod
    def create_parse_expression(self):
        pass

    def parse_all(self, instring):
        """
        Parses input string using the reader expression and returns the result.

        Args:
            instring (str): Content of input file.

        Returns:
            ParseResults: instance containing data.
        """
        return self.reader.parseString(instring, parseAll=True)
