""" Module for class for reading an MBDFSCR-file and returning the parsed result. """
from pyparsing import (CharsNotIn, Each, Group, OneOrMore, Optional, Suppress,
                       cppStyleComment, delimitedList)

from pymbdfparser.reader.reader import Reader
from pymbdfparser.reader.reader_tools import (_A_, _C_, _S, Reserved, array,
                                              intx, numx, parse_id)
from pymbdfparser.reader.script_table_tools import cmd, delay, script_command


class ScriptReader(Reader):
    """Class for reading an MBDFSCR-file and returning the parsed result."""

    def __init__(self):
        """Constructor of ScriptReader class."""

        # General
        description_file = Reserved('description_file') + _A_ + \
            Optional(Suppress('"')) + CharsNotIn(';').setResultsName("Mbdf") + Optional(Suppress('"')) + _S
        description_file.setName("MBDF_filename")
        general = description_file

        # Messages
        script_table_frame = \
            parse_id("frame_name") + _C_ +\
            Group(delimitedList(parse_id(), delim="+")).setResultsName("recipients") + _C_ +\
            (intx() | Reserved('default')).setResultsName('int_or_default1') + _C_ +\
            Optional((intx() | Reserved('default')).setResultsName('int_or_default2') + _C_) +\
            array(Group(Optional(delimitedList(numx()))).setResultsName("data"))
        script_table_entry = Group((cmd("STOP") + _S) | ((script_command() | script_table_frame) + _C_ + delay() + _S))
        messages = Group(OneOrMore(script_table_entry)).setResultsName("Messages")
        messages.setName("Script frames")

        self.general = general
        self.messages = messages
        self.reader = self.create_parse_expression()

    def create_parse_expression(self):
        """
        Combines individual LIN section to the complete parse expression.

        Returns:
            ParseExpression object to use for parsing MBDF-data.
        """
        reader = Each([
            self.general,
            self.messages,
        ])
        reader.setName("MBDFSCR")
        reader.ignore(cppStyleComment)

        return reader
