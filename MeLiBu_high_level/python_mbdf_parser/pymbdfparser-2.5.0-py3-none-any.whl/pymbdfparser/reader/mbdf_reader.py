""" Module for class for reading MBDF-files and returning the parsed result. """
from pyparsing import (Dict, Each, Empty, Group, NoMatch, OneOrMore, Optional,
                       Suppress, Word, ZeroOrMore, alphanums, alphas,
                       cppStyleComment, delimitedList)

from pymbdfparser.reader.reader import Reader
from pymbdfparser.reader.reader_tools import (_A_, _BR, _C_, _CL_, _S, BL_, FrameUnique, Reserved, SigEncUnique,
                                              SigRepUnique, block, intx, intx_ms, numx, parse_bool,
                                              parse_bus_speed, parse_id, section, text, version)
from pymbdfparser.reader.script_table_tools import (entry_label, script_command, delay)


class MbdfReader(Reader):
    """Class for reading MBDF-files and returning the parsed result."""

    def __init__(self):
        """Constructor of MBDFReader class."""

        # General
        description_file = Reserved('description_file') + _A_ + \
            Suppress('"') + Reserved('MELIBU').setResultsName('description_file') + Suppress('"') + _S
        protocol_version = Dict(Group(Reserved('bus_protocol_version') + _A_ + version() + _S))
        language_version = Dict(Group(Reserved('bus_language_version') + _A_ + version() + _S))
        bus_speed = Dict(Group(Reserved('bus_speed') + _A_ + parse_bus_speed() + _S))
        general = description_file & protocol_version & language_version & bus_speed

        general = Group(general).setResultsName("General")
        general.setName("MBDF General")
        general.ignore(cppStyleComment)

        # Node
        master = Dict(Group(Reserved("Master") + _CL_ + parse_id('node') + _S))
        slaves = Dict(Group(Reserved("Slaves") + _CL_ + Group(delimitedList(Word(alphas + alphanums + "_"))) + _S))

        node = section("Nodes", master & slaves)
        node.setName("Nodes")
        node.ignore(cppStyleComment)

        # Node_attributes
        node_attributes = \
            section(
                "Node_attributes",
                OneOrMore(
                    Dict(
                        Group(
                            parse_id() +
                            block(
                                Dict(Group(Reserved("bus_protocol") + _A_ + version() + _S)) +
                                Dict(Group(Reserved("configured_NAD") + _A_ + intx() + _S)) +
                                Dict(Group(Reserved("product_id") + _A_ + intx() + _C_ + intx() +
                                           Optional(_C_ + intx()) + _S)) +
                                Dict(Group(Reserved("response_error") + _A_ + parse_id() + _S)) +
                                Optional(Dict(Group(Reserved("fault_state_signals") + _A_ +
                                                    Group(OneOrMore(parse_id() + Optional(_C_))) + _S))) +
                                Optional(Dict(Group(Reserved("P2_min") + _A_ + intx_ms() + _S))) +
                                Dict(Group(Reserved("M2S_ACK") + _A_ + parse_bool() + _S)) +
                                Dict(Group(Reserved('supported_frames') + block(Group(ZeroOrMore(parse_id() + _S)))))
                            )
                        )
                    )
                )
            )

        node_attributes.setName("Node_attributes")
        node_attributes.ignore(cppStyleComment)

        # Signals
        signal = \
            section("Signals",
                    OneOrMore(Dict(Group(parse_id() + _CL_ + intx("size") + _C_ +
                                         intx("init_value", cast_to_int=False) + _C_ +
                                         Group(OneOrMore(parse_id() + Optional(_C_)))
                                         .setResultsName("subscribed_by_list") + _S))))
        signal.setName("Signals")
        signal.ignore(cppStyleComment)

        # Frames
        frame = section("Frames",
                        Empty().setParseAction(FrameUnique.reset) +  # Reset frame names first
                        OneOrMore(
                            Dict(Group(
                                parse_id() + _CL_ +
                                (Reserved('M2S') | Reserved('S2M')).setResultsName('direction') + _C_ +
                                (Reserved('LED_EXTENDED') | Reserved('LED') | Reserved('DATA'))
                                .setResultsName('function_type') + _C_ +
                                (parse_id('subaddr_or_pl_length') | intx('subaddr_or_pl_length')) + _C_ +
                                Optional((parse_bool()).setResultsName('frame_i_select') + _C_) +
                                (parse_id() | intx() | Reserved('NONE')).setResultsName('instruction') +
                                Group(BL_ + ZeroOrMore(Dict(Group(parse_id() + _C_ + intx() + _S))) + _BR)
                                .setResultsName("signals")
                            )).setParseAction(FrameUnique.check)  # Warn about duplicates
                        ))
        frame.setName("Frames")
        frame.ignore(cppStyleComment)

        # Schedule_tables
        sch_table_frame = parse_id("frame_name") + _C_ + parse_id("node_name")
        sch_table_entry = Group(entry_label() + (script_command() | sch_table_frame) + _C_ + delay() + _S)

        schedule_table = section("Schedule_tables",
                                 OneOrMore(Dict(Group(parse_id() + block(Group(OneOrMore(sch_table_entry)))))))
        schedule_table.setName("Schedule_tables")
        schedule_table.ignore(cppStyleComment)

        # Signal_encoding_types
        _lv = Reserved("logical_value") + _C_ + intx("signal_value") + Optional(_C_ + text("text_info"))
        _pr = Reserved("physical_value") + _C_ + numx("min_value") + _C_ + numx("max_value") + _C_ + \
            numx("scale") + _C_ + numx("offset") + Optional(_C_ + text("text_info"))

        signal_encoding_type = \
            section("Signal_encoding_types",
                    Empty().setParseAction(SigEncUnique.reset) +  # Reset signal encoding types first
                    OneOrMore(
                        Dict(
                            Group(parse_id() + block(OneOrMore(Dict(Group((_lv | _pr) + _S)))))
                        ).setParseAction(SigEncUnique.check)  # Check for duplicates
                    ))
        signal_encoding_type.setName("Signal_encoding_types")
        signal_encoding_type.ignore(cppStyleComment)

        # Signal_representation
        signal_representation = \
            section("Signal_representation",
                    Empty().setParseAction(SigRepUnique.reset) +  # Reset signal representation first
                    OneOrMore(
                        Dict(
                            Group(parse_id() + _CL_ + Group(parse_id() + ZeroOrMore(_C_ + parse_id())) + _S)
                        ).setParseAction(SigRepUnique.check)  # Check for duplicates
                    ))
        signal_representation.setName("Signal_representation")
        signal_representation.ignore(cppStyleComment)

        self.general = general
        self.node = node
        self.node_attributes = node_attributes
        self.signal = signal
        self.frame = frame
        self.schedule_table = schedule_table
        self.signal_encoding_type = signal_encoding_type
        self.signal_representation = signal_representation
        self.reader = self.create_parse_expression()

    def create_parse_expression(self):
        """
        Combines individual LIN section to the complete parse expression.

        Returns:
            ParseExpression object to use for parsing MBDF-data.
        """
        reader = Each([
            self.general,
            self.node,
            self.signal,
            self.frame,
            self.node_attributes,
            self.schedule_table,
            Optional(self.signal_encoding_type),
            Optional(self.signal_representation),
        ]) - Optional(NoMatch().setName("identifier/section"))
        reader.setName("MBDF")
        reader.ignore(cppStyleComment)

        return reader
