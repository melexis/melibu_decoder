""" Module that provides helper functions for processing input files """
import logging
import re

from pyparsing import (CaselessLiteral, Combine, Dict, Group,
                       ParseFatalException, QuotedString, Regex, Suppress,
                       Word, nums, pyparsing_common)

BL_ = Suppress("{")  # Open curly bracket
_BR = Suppress("}")  # Close curly bracket
SL_ = Suppress("[")  # Open square bracket
_SR = Suppress("]")  # Close square bracket
_C_ = Suppress(",")  # Comma
_S = Suppress(";")  # Semicolon
_CL_ = Suppress(":")  # Colon
_A_ = Suppress("=")  # Assign
_Q_ = Suppress('"')  # Double quotation marks
_P_ = Suppress("+")  # Plus sign
INTEGER = Regex(r"-?((0x[a-f\d]+)|(0b[01]+)|(\d+(e\d+)?))", re.I)
REAL = Regex(r"-?(\d+(\.\d+)?(e-\d+)?)", re.I)

# Switch case-sensite / case-insensitive
Reserved = CaselessLiteral  # Use Literal if case is important

LOGGER = logging.getLogger('pymbdfparser')


# Helper reader actions
def to_int(t):
    """Casts and returns the input value as an integer value."""
    input_str = t[0]
    try:
        return int(input_str, base=0)
    except ValueError:
        decimal = float(input_str)
        integer = int(decimal)
        if integer != decimal:
            raise TypeError("Expected integer; got float ({})".format(input_str))
        return integer


def to_float(t):
    """Casts and returns the input value as a float value."""
    return float(t[0])


# Grouping
def block(content):
    "Block surrounded by curly braces"
    return BL_ + content + _BR


def array(content):
    "Block surrounded by square brackets"
    return SL_ + content + _SR


def section(identifier, content):
    "Block surrounded by curly braces, begins with identifier"
    return Dict(Group(Reserved(identifier) + block(content)))


def parse_id(name_=None):
    """identifier: An identifier. Typically used to name objects. Identifiers shall
    follow the normal C rules for variable declaration """

    id_ = pyparsing_common.identifier
    if name_:
        return id_.setResultsName(name_)
    else:
        return id_


def intx(name_=None, cast_to_int=True):
    """int/str: An integer when cast_to_int is truthy, str otherwise. The value can be in decimal or
    hexadecimal (prefixed with 0x) or binary (prefixed with 0b) or scientific format """
    integer = INTEGER
    if cast_to_int:
        integer.setParseAction(to_int)
    else:
        integer.setParseAction()
    if name_:
        return integer.setResultsName(name_)
    return integer


def intx_ms(name_=None):
    "integer_bits: postfixed ms"
    return intx(name_) + Suppress("ms")


def intx_pr(name_=None):
    "integer: postfixed with %"
    return intx(name_) + Suppress("%")


def numx(name_=None):
    """real_or_integer: A real or integer number. A real number is always in decimal
    and has an embedded decimal point."""

    number = INTEGER.setParseAction(to_int) ^ REAL.setParseAction(to_float)
    if name_:
        return number.setResultsName(name_)
    else:
        return number


def numx_ms(name_=None):
    "real_or_integer ms: postfixed ms"
    return numx(name_) + Suppress("ms")


def parse_bus_speed():
    "real_or_integer ms: postfixed Mbps or kbps"
    return numx('speed') + (Reserved('Mbps') | Reserved('kbps')).setResultsName('speed_unit')


def _fix_version(parse_result):
    return float(parse_result[0])


def version():
    "float in range of 1.0 to 99.99"
    return Combine(Suppress('"') + Word(nums + ".", min=3, max=5) + Suppress('"')).setParseAction(_fix_version)


def text(name_=None):
    "Quoted string"
    txt_ = QuotedString('"')
    if name_:
        return txt_.setResultsName(name_)
    else:
        return txt_


def parse_bool():
    "True or False"
    return Reserved("True") | Reserved("False")


class FrameUnique:
    "Pico namespace for Frames unique identifier"

    identifiers = {}

    @classmethod
    def reset(cls, *_):
        """ Resets container of identifiers """
        cls.identifiers = {}

    @classmethod
    def check(cls, parsed_string, loc, obj):
        """ Checks container of identifiers for duplicates """
        if obj[0][0] in cls.identifiers:
            LOGGER.warning("Frames section: frame name %s is not unique", obj[0][0])
        cls.identifiers[obj[0][0]] = True
        return obj


class SigEncUnique:
    "Pico namespace for Signal_encoding_types unique identifier"

    identifiers = {}

    @classmethod
    def reset(cls, *_):
        """ Resets container of identifiers """
        cls.identifiers = {}

    @classmethod
    def check(cls, parsed_string, loc, obj):
        """ Checks container of identifiers for duplicates """
        if obj[0][0] in cls.identifiers:
            raise ParseFatalException(parsed_string, loc, "Signal_encoding_types, Type %s duplicated!" % obj[0][0])
        cls.identifiers[obj[0][0]] = True
        return obj


class SigRepUnique:
    "Pico namespace for checking uniqueness of <signal_name> entries"

    identifiers = {}

    @classmethod
    def reset(cls, s, loc, t):
        cls.identifiers = {}

    @classmethod
    def check(cls, s, loc, t):
        signals = t[0][1]
        for signal in signals:
            if signal in cls.identifiers:
                raise ParseFatalException(s, loc, "Signal_representation, Signal %s duplicated!" % signal)
            cls.identifiers[signal] = True
        return t
