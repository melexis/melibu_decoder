""" Module for defining custom error classes."""


class MbdfError(Exception):
    """ Error class for raising errors in MBDF-file. """


class MbdfNodeNotFoundError(MbdfError):
    """ Error class for raising node-not-found errors in MBDF file. """


class MbdfFrameNotFoundError(MbdfError):
    """ Error class for raising frame-not-found errors in MBDF file. """


class MbdfMissingModelError(MbdfError):
    """ Error class for when an MBDF child item (frame, node, schedule, etc.)
    can't access the parent model. """
