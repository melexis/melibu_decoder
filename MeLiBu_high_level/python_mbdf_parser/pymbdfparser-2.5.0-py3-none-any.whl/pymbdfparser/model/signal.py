""" Module for the Signal class """
from operator import attrgetter

from pymbdfparser.model.element import MbdfElement
from pymbdfparser.model.node_base import Node


class Signal(MbdfElement):
    """ Class for identifying the name and properties of all signals.

    Identifies the name of all signals in the cluster and their properties.
    The definitions in this class create a signal identifier set. All identifiers in this set shall be unique.

    Attributes:
        name (str): Unique name of the signal.
        size (int): Specifies the size of the signal in bits.
        init_value (int): Specifies the signal value that shall be used by all subscriber nodes until the
                frame containing the signal is received.
        bus_value (int|list): Value of this signal as transmitted on the Melibu bus.
        signal_value (str): Human readable (decoded) signal value as was last received (or initial value if none
            received yet).
        value_repr (method): Method to convert integer value to string representation.
        c_val (str): The value of the bit field in C.
        c_type (str): The type of the bit field in C.
        subscribers (list): List of Node objects subscribed to this signal.
        encoding_type (SignalEncodingType): SignalEncodingType to use for encoding and decoding.
    """
    def __init__(self, name, size, init_value, model=None):
        """ Constructor of the Signal class.

        Args:
            name (str): Unique name of the signal.
            size (int): Specifies the size of the signal in bits.
            init_value (int): Specifies the signal value that shall be used by all subscriber nodes until the
                frame containing the signal is received.
            model (MbdfModel): Parent model that contains this signal
        """
        super().__init__(model=model)
        self._name = name
        self._size = size
        self._init_value = init_value
        self._bus_value = None
        self.bus_value = init_value
        self._value_repr = str
        self._subscribers = []
        self.encoding_type = None

    def __int__(self):
        if not isinstance(self.bus_value, int):
            raise TypeError(f"The value of signal {self.name!r} is not an integer; got "
                            f"{self.bus_value.__class__.__name__!r}")
        return self.bus_value

    def __eq__(self, other):
        """
        Tests two objects for equality based on attribute values. Comparing length of subscribers list to prevent
        recursion errors.

        Args:
            other (Signal): Signal instance

        Returns:
            bool: Whether both dict attributes are equal or not.
        """
        if type(other) is type(self):
            return self.name == other.name and self.size == other.size and self.bus_value == other.bus_value and \
                len(self.subscribers) == len(other.subscribers)
        return False

    def __repr__(self):
        return self._value_repr(self.bus_value)

    @property
    def name(self):
        """ str: Gets the signal name."""
        return self._name

    @property
    def size(self):
        """ int: Gets the signal size in bits."""
        return self._size

    @size.setter
    def size(self, value):
        self._size = value

    @property
    def init_value(self):
        """ int: initial value."""
        return self._init_value

    @property
    def bus_value(self):
        """ int: current bus value. """
        return self._bus_value

    @bus_value.setter
    def bus_value(self, value):
        upper_bound = pow(2, self.size)
        if value >= upper_bound:
            raise ValueError(f"Signal {self.name!r} with size {self.size} bits must have a value lower than "
                             f"{upper_bound}; got {value}")
        if value < 0:
            raise ValueError(f"Signal {self.name!r} cannot have a negative value; got {value}")
        self._bus_value = value

    @property
    def signal_value(self):
        """ str: value of the signal represented in human readable format """
        return self.decode(self.bus_value)

    @signal_value.setter
    def signal_value(self, value):
        self.bus_value = self.encode(value)

    @property
    def value_repr(self):
        """ func: Gets the method used to convert the signal value to its representation in the MBDF."""
        return self._value_repr

    @value_repr.setter
    def value_repr(self, value):
        self._value_repr = value

    @property
    def c_val(self):
        """ str: The value of the bit field in C."""
        result = ""
        if self.size == 1:
            if self.bus_value:
                result = "true"
            else:
                result = "false"
        elif self.size <= 8:
            result = f"0x{self.bus_value:02X}u"
        elif self.size <= 16:
            result = f"0x{self.bus_value:04X}u"
        elif self.size <= 32:
            result = f"0x{self.bus_value:08X}u"
        else:
            result = f"0x{self.bus_value:016X}u"
        return result

    @property
    def c_type(self):
        """ str: The type of the bit field in C."""
        if self.size == 1:
            return "m_bool"
        if self.size <= 8:
            return "m_u8"
        if self.size <= 16:
            return "m_u16"
        if self.size <= 32:
            return "m_u32"
        return "m_u64"

    @property
    def subscribers(self):
        """ list: Gets the list of Node objects subscribed to the signal sorted on node name."""
        return sorted(self._subscribers, key=attrgetter('name'))

    def add_subscriber(self, node):
        """ Adds subscriber node to the list subscribers.

        Args:
            node (Node): Node instance subscribed to the signal.

        Raises:
            TypeError: The type of the passed argument is wrong.
        """
        if not isinstance(node, Node):
            raise TypeError("Type must be Node but encountered %s." % node.__class__)
        self._subscribers.append(node)

    def encode(self, value):
        """ Encode a human readable value into a bus value for this signal

        Args:
            value (str|int): value to be encoded.

        Returns:
            int: Encoded value for this signal.

        Raises:
            ValueError: Could not encode the value.
        """
        if self.encoding_type:
            result = self.encoding_type.encode(value)
            if result is None:
                raise ValueError(f"Could not encode value {value!r} for signal {self.name!r} with signal encoding type "
                                 f"{self.encoding_type.name!r}")
        elif isinstance(value, int):
            result = value
        else:
            result = int(value, 0)
        return result

    def decode(self, value):
        """ Decodes a value into a human readable value.

        Args:
            value (int): value to be decoded.

        Returns:
            str: Value formatted in human readable format.

        Raises:
            ValueError: Could not decode the value.
        """
        if self.encoding_type:
            result = self.encoding_type.decode(value)
            if result is None:
                raise ValueError(f"Could not decode value {value!r} for signal {self.name!r} with signal encoding type "
                                 f"{self.encoding_type.name!r}")
        else:
            result = str(value)
        return result
