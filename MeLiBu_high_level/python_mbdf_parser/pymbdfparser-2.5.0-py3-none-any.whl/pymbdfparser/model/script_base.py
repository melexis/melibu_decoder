""" Module for the ScriptBase class """
from abc import ABC

from pymbdfparser.model.element import MbdfElement


class ScriptBase(MbdfElement, ABC):
    """ Abstract base class for Melibu script "messages" (frames, wakeups, etc.) """

    _script_type = ""

    def __init__(self, model=None, **kwargs):
        """ Constructor """
        super().__init__(model=model, **kwargs)
        self._delay_us = 0
        self._min_response_time_ms = 0

    def __str__(self):
        return "Melibu script base class"

    @property
    def script_type(self):
        """ int: type of script content """
        return self._script_type

    @property
    def delay_us(self):
        """ int: the delay in us for this frame """
        return self._delay_us

    @delay_us.setter
    def delay_us(self, value):
        self._delay_us = value

    @property
    def min_response_time_ms(self):
        """ int: the minimum time in ms which is needed by the slave to respond """
        return self._min_response_time_ms

    @min_response_time_ms.setter
    def min_response_time_ms(self, value):
        self._min_response_time_ms = value
