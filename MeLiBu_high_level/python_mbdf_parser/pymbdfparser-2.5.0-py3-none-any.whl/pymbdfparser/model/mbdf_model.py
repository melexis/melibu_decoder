""" Module for the MbdfModel class """
from pymelibuframe import Melibu1LedFrame

from pymbdfparser.model.exceptions import MbdfModelException
from pymbdfparser.model.node_base import Node
from pymbdfparser.model.signal import Signal
from pymbdfparser.model.frame_base import FrameBase
from pymbdfparser.model.schedule_table import ScheduleTable
from pymbdfparser.model.signal_representation import SignalRepresentation

SUPPORTED_PROTOCOLS = {
    1.0: Melibu1LedFrame.NORMAL_MODE,
    1.1: Melibu1LedFrame.EXTENDED_MODE,
    2.0: None,
}
SUPPORTED_LANGUAGES = (1.2, )


class MbdfModel:
    """ Top class used to store all objects during parsing.

    Attributes:
        mbdf_path (pathlib.Path): Absolute path to the MBDF.
        mbdf_filename (str): Filename of MBDF.
        description_file_type (str): Equal to "MELIBU".
        bus_protocol_version (float): MeLiBu protocol version number definition in the range of "1.0" to "99.99".
        bus_language_version (float): Describes the version of the MBDF Format. Shall be in the range of "1.0" to
            "99.99".
        bus_speed (int): The nominal bit rate for the cluster (in bps). The maximum supported value is 2Mbit/s.
        current_bus_speed (int): Actual bit rate used by frames in the model (in bps). Defaults to bus_speed
            but can be overridden.
        nodes (dict): Dict for storing Node objects, with node names as keys.
        signals (dict): Dict for storing Signal objects, with signal names as keys.
        frames (dict): Dict for storing Frame objects, with frame names as keys.
        schedule_tables (dict): Dict for storing ScheduleTable objects, with schedule table names as keys.
        signal_representations (list): List for storing SignalRepresentation objects, which don't have a name.
        script_table (ScriptTable): ScriptTable instance in case of an input MBDFSCR file.
    """

    def __init__(self, file_path, description_file_type, protocol_version, language_version, speed):
        """ Constructor of MbdfModel class.

        Args:
            file_path (pathlib.Path): Path to the MBDF.
            description_file_type (str): Equal to "MELIBU".
            protocol_version (int|float): MeLiBu protocol version number definition in the range of "0.01" to "99.99".
            language_version (int|float): MeLiBu language specification version number definition in the range of
                "0.01" to "99.99".
            speed (float|int): Sets the nominal bit rate for the cluster (1 to 20 kbps).
        """
        self.mbdf_path = file_path.resolve()
        self._description_file_type = description_file_type
        self._bus_protocol_version = None
        self.bus_protocol_version = protocol_version
        self._bus_language_version = None
        self.bus_language_version = language_version
        self._bus_speed = speed
        self.current_bus_speed = speed
        self._nodes = {}
        self._signals = {}
        self._frames = {}
        self._schedule_tables = {}
        self._signal_representations = []
        self.script_table = None

    def __eq__(self, other):
        """ Tests two objects for equality based on attribute values.

        Args:
            other (MbdfModel): MbdfModel instance.
        Returns:
            bool: Whether both dict attributes and object types are equal or not.
        """
        if type(other) is type(self):
            return self.__dict__ == other.__dict__
        return False

    @property
    def mbdf_filename(self):
        """ str: Filename of MBDF. """
        return self.mbdf_path.name

    @property
    def description_file_type(self):
        """ str: Gets the description_file_type."""
        return self._description_file_type

    @property
    def bus_protocol_version(self):
        """ float: Gets the bus_protocol_version."""
        return self._bus_protocol_version

    @property
    def bus_language_version(self):
        """ float: Gets the bus_language_version."""
        return self._bus_language_version

    @property
    def bus_speed(self):
        """ Gets the bus_speed (in bps)."""
        return self._bus_speed

    @property
    def nodes(self):
        """ Gets the nodes as a dict, sorted on its keys."""
        return self._nodes

    @property
    def master_node(self):
        """ Gets the master node.

        Raises:
            MbdfModelException: The model does not contain a master node.
        """
        for node in self.nodes.values():
            if node.TYPE == "MASTER":
                return node
        raise MbdfModelException("The model does not contain a master node.")

    @property
    def slave_nodes(self):
        """ Gets the slave nodes as a dict """
        return {name: node for name, node in self.nodes.items() if node.TYPE == "SLAVE"}

    @property
    def broadcast_nodes(self):
        """ Gets the broadcast nodes as a dict """
        return {name: node for name, node in self.nodes.items() if node.TYPE == "BROADCAST"}

    @property
    def signals(self):
        """ Gets the signals as a dict, sorted on its keys."""
        return self._signals

    @property
    def frames(self):
        """ Gets the frames as a dict, sorted on its keys."""
        return self._frames

    @property
    def schedule_tables(self):
        """ Gets the schedule_tables as a dict, sorted on its keys."""
        return self._schedule_tables

    @property
    def signal_representations(self):
        """ Gets the list of signal representations."""
        return self._signal_representations

    @bus_protocol_version.setter
    def bus_protocol_version(self, version):
        version = float(version)
        if version not in SUPPORTED_PROTOCOLS:
            raise ValueError("The tool does not support MeLiBu protocol version %s." % version)
        self._bus_protocol_version = version

    @bus_language_version.setter
    def bus_language_version(self, version):
        version = float(version)
        if version not in SUPPORTED_LANGUAGES:
            raise ValueError("The tool does not support MeLiBu language version %s." % version)
        self._bus_language_version = version

    def add_node(self, node):
        """ Adds a node to the nodes dict with its name as key value.

        Args:
            node (Node): Instance of Node class to be added to the nodes dict.
        Raises:
            TypeError: Type must be Node
        """
        if not isinstance(node, Node):
            raise TypeError("Type must be Node; got %s." % node.__class__.__name__)
        self._nodes[node.name] = node

    def add_signal(self, signal):
        """ Adds a signal to the signals dict with its name as key value.

        Args:
            signal (Signal): Instance of Signal class to be added to the signals dict.
        Raises:
            TypeError: Type must be Signal
        """
        if not isinstance(signal, Signal):
            raise TypeError("Type must be Signal; got %s." % signal.__class__.__name__)
        self._signals[signal.name] = signal

    def add_frame(self, frame):
        """ Adds a frame to the frames dict with its name as key value.

        Args:
            frame (FrameBase): Instance with FrameBase as base class to be added to the frames dict.
        Raises:
            TypeError: Type must be FrameBase
        """
        if not isinstance(frame, FrameBase):
            raise TypeError("Type must be FrameBase; got %s." % frame.__class__.__name__)
        self._frames[frame.name] = frame

    def add_schedule_table(self, schedule_table):
        """ Adds a schedule_table to the schedule_tables dict with its name as key value.

        Args:
            schedule_table (ScheduleTable): ScheduleTable object to be added to the schedule_tables dict.
        Raises:
            TypeError:                  The type of the passed argument is wrong.
            MbdfModelException:         The schedule table's name is not unique.
        """
        if not isinstance(schedule_table, ScheduleTable):
            raise TypeError("Type must be ScheduleTable; got %s." % schedule_table.__class__.__name__)
        if schedule_table.name in self.schedule_tables:
            raise MbdfModelException("Schedule table name '%s' is not unique." % schedule_table.name)
        self._schedule_tables[schedule_table.name] = schedule_table

    def add_signal_representation(self, signal_representation):
        """ Adds a signal_representation to the signal_representations list.

        Args:
            signal_representation (SignalRepresentation):   SignalRepresentation object to be added to the
                                                            signal_representations list.
        Raises:
            TypeError: The type of the passed argument is wrong.
        """
        if not isinstance(signal_representation, SignalRepresentation):
            raise TypeError("Type must be SignalRepresentation; got %s." % signal_representation.__class__.__name__)
        self._signal_representations.append(signal_representation)
