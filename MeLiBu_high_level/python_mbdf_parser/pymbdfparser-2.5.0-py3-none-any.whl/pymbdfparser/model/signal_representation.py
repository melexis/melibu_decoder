""" Module for the SignalRepresentation class """
from pymbdfparser.model.signal import Signal
from pymbdfparser.model.signal_encoding_type import SignalEncodingType


class SignalRepresentation:
    """ Class for associating signals with the corresponding signal encoding type.

    Attributes:
        encoding_type (SignalEncodingType): SignalEncodingType instance used.
        signals (dict): Dictionary of Signal objects with their name as key.
    """

    def __init__(self, encoding_type):
        """ Inits SignalRepresentation with its associated encoding.

        Args:
            encoding_type (SignalEncodingType): SignalEncodingType instance used.
        Raises:
            TypeError: The type of the passed encoding_type argument is wrong.
        """
        if not isinstance(encoding_type, SignalEncodingType):
            raise TypeError("Type must be SignalEncodingType but encountered %s." % encoding_type.__class__)
        self._encoding_type = encoding_type
        self._signals = {}

    def __eq__(self, other):
        """ Tests two objects for equality based on attribute values.

        Args:
            other (SignalRepresentation): SignalRepresentation instance
        Returns:
            Whether both dict attributes and object types are equal or not.
        """
        if type(other) is type(self):
            return self.__dict__ == other.__dict__
        return False

    @property
    def encoding_type(self):
        """ Gets the encoding type."""
        return self._encoding_type

    @property
    def signals(self):
        """ Gets the dictionary of signals with signal names as keys."""
        return self._signals

    def add_signal(self, signal):
        """ Adds a signal to the dictionary of signals with its name as key.

        Args:
            signal (Signal): Instance of Signal class.
        Raises:
            TypeError: The type of the passed signal argument is wrong.
        """
        if not isinstance(signal, Signal):
            raise TypeError("Type must be Signal but encountered %s." % signal.__class__)
        self._signals[signal.name] = signal
        signal.encoding_type = self.encoding_type
