""" Module for the FrameBase class """
from abc import ABC, abstractmethod
from operator import attrgetter
from struct import unpack

from pymelibuframe import MelibuFrameBase

from pymbdfparser.model.element import MbdfElement
from pymbdfparser.model.signal import Signal
from pymbdfparser.model.signal_encoding_type import PhysicalEncoding


class FrameBase(MbdfElement, MelibuFrameBase, ABC):
    """ Base Melibu frame class """

    def __init__(self, model=None):
        """ Constructor of the FrameBase class.

        Args:
            model (MbdfModel): Parent model that contains this frame.
        """
        super().__init__(model=model)
        self._name = ""
        self._signals = []

    @property
    @abstractmethod
    def offset_signal_class(self):
        """ OffsetSignalBase: subclass used by the protocol-version-specific signal packing scheme. """

    @property
    def baudrate(self):
        """ int: baudrate for this frame; inherited from parent MbdfModel. """
        return self.model.current_bus_speed

    @property
    def function_bit(self):
        """ int: 1 if function type is LED, 0 if function type is Command """
        if self.function_type not in ("LED", "Command"):
            raise ValueError(f"Cannot determine Function Select bit as function_type is invalid; "
                             f"got {self.function_type!r}")
        return int(self.function_type == "LED")

    @property
    @abstractmethod
    def bitorder(self):
        """ str: Must be either 'big' (most-significant bit transmitted first)
        or 'little' (least-significant bit transmitted first) """

    @property
    @abstractmethod
    def byteorder(self):
        """ str: Must be either 'big' (most-significant byte transmitted first within each word)
        or 'little' (least-significant byte transmitted first within each word). """

    @property
    @abstractmethod
    def wordorder(self):
        """ str: Must be either 'big' (most-significant word transmitted first) or 'little'
        (least-significant word transmitted first). Only relevant for multi-word signals. """

    @property
    def payload(self):
        """ bytearray: the payload of this frame; defined by the setter """
        return self._payload

    @payload.setter
    def payload(self, data):
        self._payload = data

    @property
    @abstractmethod
    def max_size(self):
        """ int: maximum logical payload size in bytes """

    @property
    def signals(self):
        """ list: list of offset signals as namedtuples with typename OffsetSignal sorted on offset value """
        return sorted(self._signals, key=attrgetter('offset'))

    @property
    def unsorted_signals(self):
        """ list: list of offset signals as namedtuples with typename OffsetSignal in the order as in MBDF """
        return self._signals

    @property
    def signal_chunks_little_endian(self):
        """ list: signal chunks, as seen by a little-endian master without word-swapping.
                  That is, LSBit first, MSByte first """
        chunks = []
        for signal in self.unsorted_signals:
            chunks.extend(signal.signal_chunks_little_endian)
        chunks.sort(key=lambda chunk: chunk.real_offset)
        return chunks

    @property
    def signal_chunks_big_endian(self):
        """ list: signal chunks, as seen by a big-endian master without word-swapping.
                  That is, MSBit first, MSByte first """
        chunks = []
        for signal in self.unsorted_signals:
            chunks.extend(signal.signal_chunks_big_endian)
        chunks.sort(key=lambda chunk: chunk.real_offset)
        return chunks

    @property
    def signal_chunks_little_wordswap(self):
        """ list: signal chunks in the Mlx16-native little endian-with-wordswap format. """
        chunks = []
        for signal in self.unsorted_signals:
            chunks.extend(signal.signal_chunks_little_wordswap)
        chunks.sort(key=lambda chunk: chunk.real_offset)
        return chunks

    def add_signal(self, signal, offset, **_):
        """ Adds a namedtuple OffsetSignalMelibu1 or OffsetSignalMelibu2 to the signals list.

        Args:
            signal (Signal): Signal instance to be added to the signals list.
            offset (int): Offset of the signal to be added to the signals list.
                The offset starts at the LSBit of Dataword[0] and gets incremented till the MSBit of the Word
                (offset = 15). After reaching the MSBit of the Dataword[0], the offset gets incremented again, starting
                at the LSBit of Dataword[1] et cetera.

        Raises:
            TypeError: The type of the passed signal argument is wrong.
            ValueError: The value of offset and/or signal.size is/are wrong.
        """
        if offset < 0:
            raise ValueError("%s: Signal %s cannot have a negative offset (%d)." % (self.name, signal.name, offset))
        if not isinstance(signal, Signal):
            raise TypeError("Type must be Signal; got %s." % signal.__class__.__name__)

        # add signal to list
        self._signals.append(self.offset_signal_class(signal, offset))

        total_size = 0
        tail = 0
        for offset_signal in self.signals:
            # checking for overlap between consecutive signals
            if tail > offset_signal.offset:
                raise ValueError("There is an overlap of {} bit(s) between signal '{}' and its preceding signal in "
                                 "frame '{}'.".format(tail - offset_signal.offset, offset_signal.signal.name,
                                                      self.name))
            tail = offset_signal.offset + offset_signal.signal.size
            total_size += offset_signal.signal.size

    def bitstring_to_bytes(self, bitstring):
        """ Converts a string of zeroes and ones to a bytes object.

        Args:
            bitstring (str): String of zeroes and ones

        Returns:
            bytes: Bytes object
        """
        if bitstring:
            return int(bitstring, 2).to_bytes(len(bitstring) // 8, byteorder=self.byteorder)
        return b""

    def create_payload(self, filler_bit=0):
        """ Creates the data payload based on the signals of the frame and their offset.

        Args:
            filler_bit (int): Value of the bit used to fill any gaps. Default is 0.

        Returns:
            bytearray: The frame's entire data payload.
        """
        if not self.signals:
            return bytearray()
        filler_char = str(filler_bit)
        previous_obj = None
        bitstring = filler_char * self.signals[0].offset
        payload_bytes = b""
        for obj in self.signals:
            if previous_obj:
                # creating bitstring with correct "Signal Offset" witin Melibu data
                bitstring = filler_char * (obj.offset - (previous_obj.offset + previous_obj.signal.size)) + bitstring
            bitstring = format(obj.signal.bus_value, f'0{obj.signal.size}b') + bitstring
            previous_obj = obj
        # fill datastream till end
        max_length_in_bytes = self.size
        padding_size = max_length_in_bytes*8 - len(bitstring)
        bitstring = filler_char*padding_size + bitstring
        # bitstring contains data in correct offset order but first dataword is located in last word position
        # we need to reorder the bitstring
        for idx in range(len(bitstring), 0, -16):
            byte1 = bitstring[(idx - 8):idx]
            byte2 = bitstring[(idx - 16):(idx - 8)]
            if self.byteorder == 'little':
                payload_bytes += self.bitstring_to_bytes(byte1)
                payload_bytes += self.bitstring_to_bytes(byte2)
            else:
                payload_bytes += self.bitstring_to_bytes(byte2)
                payload_bytes += self.bitstring_to_bytes(byte1)
        payload = bytearray(payload_bytes)
        return payload[:max_length_in_bytes]

    def update_signals(self):
        """ Updates values of the frame's signals based on the frame's payload.

        As an intermediate step we use the payload to assemble a bitstring that starts with the most significant bit of
        the last word and ends with the least significant bit of the first word.
        """
        bitstring = ''
        for idx in range(len(self.payload), 0, -2):
            byte_order_char = '<' if self.byteorder == 'little' else '>'
            bitstring += format(unpack(f"{byte_order_char}H", self.payload[(idx - 2):idx])[0], '016b')

        for obj in self.signals:
            if obj.offset == 0:
                bitsubstring = bitstring[(-obj.offset - obj.signal.size):]
            else:
                bitsubstring = bitstring[(-obj.offset - obj.signal.size):-obj.offset]

            if bitsubstring:
                obj.signal.bus_value = int(bitsubstring, 2)

    def transmit_pre_process(self, node, signal_values=()):
        """ Executes actions before transmitting this frame

        Args:
             node (SlaveNode): Slave node to communicate with
             signal_values (list): Signal values to apply before sending
        """
        self.slave_address = node.configured_nad

        if self.master_to_slave:
            if 0 < len(signal_values) != len(self.unsorted_signals):
                raise ValueError(f"Expected exactly {len(self.unsorted_signals)} signal values for frame "
                                 f"{self.name}; got {len(signal_values)}.")

            for new_value, (signal, _) in zip(signal_values, self.signals):
                signal.bus_value = new_value
                if signal.encoding_type is not None:
                    for encoding in signal.encoding_type.encodings:
                        if isinstance(encoding, PhysicalEncoding):
                            signal.signal_value = new_value
                            break

            self.payload = self.create_payload()
            self.check_ack = node.m2s_ack
        else:
            if signal_values:
                raise ValueError("Cannot set signal values in S2M frame")
            self.payload = bytearray()  # payload must be empty for S2M frames

    def receive_post_process(self, force_update_master_signals=False):
        """ Executes actions after receiving this frame

        Args:
            force_update_master_signals (bool): Forcing function to update signals from Master to slave frame
        """
        if not self.master_to_slave or force_update_master_signals:
            self.update_signals()
