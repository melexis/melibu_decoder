""" Module for defining custom error classes."""


class MbdfModelException(Exception):
    """ Custom exception for the MBDF Model module """
