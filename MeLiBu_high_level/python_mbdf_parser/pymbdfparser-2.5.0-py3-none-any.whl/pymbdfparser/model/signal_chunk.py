""" Module for the SignalChunk class """
from abc import ABC, abstractmethod
from collections import namedtuple


class SignalChunk:
    """ Class representing part of a signal in a struct."""

    def __init__(self, signal, significance, real_offset, size=-1):
        """ Constructor

        Args:
            signal (Signal): Signal that this chunk belongs to.
            significance (int): 0 = least significant chunk for little endian,
                most significant chunk for big endian.
            real_offset (int): Offset in C structure, starting from least-significant
                bit for little endian and most-significant bit for big endian.
            size (int): Size of this chunk, in bits.
        """
        self.signal = signal
        self.significance = significance
        self.real_offset = real_offset
        self.size = size

    def __str__(self):
        return (f"Chunk {self.significance} of signal {self.signal.name} "
                f"offset {self.real_offset}, size {self.size} bits")

    def __repr__(self):
        return f"({self.signal.name}, {self.significance}, {self.size}@{self.real_offset})"


class OffsetSignalBase(namedtuple('OffsetSignal', ['signal', 'offset']), ABC):
    """ Class representing a signal in native payload packing scheme """
    __slots__ = ()

    def __eq__(self, other):
        """ Equality test function to allow comparison to plain Signal type """
        if other is self or other is self.signal:
            return True
        try:
            if other.signal == self.signal and other.offset == self.offset:
                return True
        except AttributeError:
            return False
        return False

    @property
    @abstractmethod
    def signal_chunks_little_endian(self):
        """ list: signal chunks, as seen by a little-endian master without word-swapping """

    @property
    @abstractmethod
    def signal_chunks_big_endian(self):
        """ list: signal chunks, as seen by a big-endian master without word-swapping """

    @property
    def real_offset_le(self):
        """ int: Real offset of this signal, assuming bit 0 = LSBit of MSByte """
        return self.__class__.conv_offset_le(self.offset)

    @property
    def real_offset_be(self):
        """ int: Real offset of this signal, assuming bit 0 = MSBit of MSByte """
        return self.__class__.conv_offset_be(self.offset)

    @staticmethod
    @abstractmethod
    def conv_offset_le(offset):
        """ int: convert from MeLiBu bit position number to real offset, assuming bit 0 = LSBit of MSByte """

    @staticmethod
    @abstractmethod
    def conv_offset_be(offset):
        """ int: convert from MeLiBu bit position number to real offset, assuming bit 0 = MSBit of MSByte """


class OffsetSignalMelibu1(OffsetSignalBase):
    """ Class representing a signal in the MeLiBu 1.x payload packing scheme
    (MSbit first, MSbyte first, LSword first) """

    MAX_FRAME_SIZE = 128

    @property
    def signal_chunks_little_endian(self):
        """ list: signal chunks, as seen by a little-endian master without word-swapping.
        That is, LSBit first, MSByte first. The chunks are sorted from LEAST to MOST significant. """

        chunks = [SignalChunk(self.signal, 0, self.real_offset_le)]
        byte_boundaries = [x for x in range(7, self.MAX_FRAME_SIZE * 8, 8)
                           if self.offset <= x < (self.offset + self.signal.size - 1)]

        # A signal can only be kept whole if it fits in a single byte. Otherwise, it will be broken into
        # at least two chunks. Start at the signal "offset" and iterate on byte boundaries until we get
        # to "offset" + length
        for significance, offset in enumerate(byte_boundaries):
            chunks[-1].size = self.conv_offset_le(offset) - chunks[-1].real_offset + 1
            chunks.append(SignalChunk(self.signal,
                                      significance + 1,
                                      self.conv_offset_le(offset + 1)))

        chunks[-1].size = self.conv_offset_le(self.offset + self.signal.size - 1) - chunks[-1].real_offset + 1
        chunks.sort(key=lambda chunk: chunk.real_offset)
        return chunks

    @property
    def signal_chunks_big_endian(self):
        """ list: signal chunks, as seen by a big-endian master without word-swapping.
        That is, MSBit first, MSByte first. The chunks are sorted from MOST to LEAST significant. """

        chunks = [SignalChunk(self.signal, 0, self.conv_offset_be(self.offset + self.signal.size - 1))]
        word_boundaries = [x for x in reversed(range(16, self.MAX_FRAME_SIZE * 8, 16))
                           if self.offset < x <= (self.offset + self.signal.size - 1)]

        # On big endian, a signal can be kept whole if it is contained within a single word,
        # due to the Mlx16 UART word swap
        for significance, offset in enumerate(word_boundaries):
            chunks[-1].size = self.conv_offset_be(offset) - chunks[-1].real_offset + 1
            chunks.append(SignalChunk(self.signal,
                                      significance + 1,
                                      self.conv_offset_be(offset - 1)))

        chunks[-1].size = self.conv_offset_be(self.offset) - chunks[-1].real_offset + 1

        chunks.sort(key=lambda chunk: chunk.real_offset)
        return chunks

    @property
    def signal_chunks_little_wordswap(self):
        """ list: signal chunks, as seen by a little-endian master with word-swapping.
        The list will only have one entry because this is the native MeLiBu byte order. """
        return [SignalChunk(self.signal,
                            0,
                            self.offset,
                            self.signal.size)]

    @staticmethod
    def conv_offset_le(offset):
        """ int: convert from MeLiBu bit position number to real offset,
        assuming bit 0 = LSBit of first (chronological) byte. """
        byte_num = offset // 8
        if byte_num % 2:
            return (byte_num - 1) * 8 + offset % 8
        return (byte_num + 1) * 8 + offset % 8

    @staticmethod
    def conv_offset_be(offset):
        """ int: convert from MeLiBu bit position number to real offset,
        assuming bit 0 = MSBit of first (chronological) byte. """
        byte_num = offset // 8
        if byte_num % 2:
            return (byte_num - 1) * 8 + 7 - offset % 8
        return (byte_num + 1) * 8 + 7 - offset % 8


class OffsetSignalMelibu2(OffsetSignalBase):
    """ Class representing a signal in the MeLiBu 2.0 payload packing scheme
    (LSbit first, LSbyte first, LSword first) """

    MAX_FRAME_SIZE = 48

    @property
    def signal_chunks_little_endian(self):
        """ list: signal chunk, as seen by a little-endian master without word-swapping.
        That is, LSBit first, LSbyte first. There is only one chunk in the list since
        this is the native byte order for MeLiBu 2. """

        chunks = [SignalChunk(self.signal, 0, self.real_offset_le, self.signal.size)]
        return chunks

    @property
    def signal_chunks_big_endian(self):
        """ list: signal chunks, as seen by a big-endian master without word-swapping.
        That is, MSBit first, MSByte first. The chunks are sorted from MOST to LEAST significant. """

        chunks = [SignalChunk(self.signal, 0, self.conv_offset_be(self.offset + self.signal.size - 1))]
        byte_boundaries = [x for x in reversed(range(8, self.MAX_FRAME_SIZE * 8, 8))
                           if self.offset < x <= (self.offset + self.signal.size - 1)]

        for significance, offset in enumerate(byte_boundaries):
            chunks[-1].size = self.conv_offset_be(offset) - chunks[-1].real_offset + 1
            chunks.append(SignalChunk(self.signal,
                                      significance + 1,
                                      self.conv_offset_be(offset - 1)))

        chunks[-1].size = self.conv_offset_be(self.offset) - chunks[-1].real_offset + 1

        chunks.sort(key=lambda chunk: chunk.real_offset)
        return chunks

    @staticmethod
    def conv_offset_le(offset):
        """ int: Return the offset unchanged; LSbit-first/LSbyte-first is native
        for MeLiBu 2. """
        return offset

    @staticmethod
    def conv_offset_be(offset):
        """ int: convert from MeLiBu bit position number to real offset,
        assuming bit 0 = MSBit of first (chronological) byte. """
        offset_in_byte = offset % 8
        return offset - offset_in_byte + (7 - offset_in_byte)
