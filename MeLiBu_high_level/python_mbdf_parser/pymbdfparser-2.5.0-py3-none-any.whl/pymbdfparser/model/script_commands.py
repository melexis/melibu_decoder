""" Module for classes representing MeLiBu script commands """

from abc import ABC

from pymbdfparser.exceptions import MbdfError
from pymbdfparser.model.script_base import ScriptBase


class ScriptAutoaddressFrame(ScriptBase):
    """ Melibu Script autoaddress frame class """

    _script_type = "Autoaddress"

    def __init__(self, model=None):
        """ Constructor """
        super().__init__(model=model)
        self._startaddress = 4
        self._node_count = 1
        self._save_nad = False

    def __str__(self):
        return (f"Melibu Script {self.script_type} with "
                f"delay[us]: {self.delay_us}, startaddress: {self.startaddress}, count: {self.node_count}, "
                f"min_resp_time: {self.min_response_time_ms}, save NAD: {self.save_nad}")

    @property
    def startaddress(self):
        """ int: the first address which should be used for autoaddressing sequence """
        return self._startaddress

    @startaddress.setter
    def startaddress(self, value):
        max_address = 254 if self.model.bus_protocol_version >= 2.0 else 63
        if 4 <= value <= max_address:
            self._startaddress = value
        else:
            raise MbdfError(f"Startaddress is exceeding allowed range from 4-{max_address}.")

    @property
    def node_count(self):
        """ int: the number of slaves which should be used for autoaddressing sequence """
        return self._node_count

    @node_count.setter
    def node_count(self, value):
        max_nodes = 251 if self.model.bus_protocol_version >= 2.0 else 60
        if 1 <= value <= max_nodes:
            self._node_count = value
        else:
            raise MbdfError(f"Number of nodes is exceeding allowed range from 1-{max_nodes}.")

    @property
    def save_nad(self):
        """ bool: true - save nad, false - do not save nad """
        return self._save_nad

    @save_nad.setter
    def save_nad(self, value):
        self._save_nad = value


class ScriptWakeupFrame(ScriptBase):
    """ Melibu Script wakeup frame class """

    _script_type = "Wakeup"

    def __init__(self, model=None):
        super().__init__(model=model)

    def __str__(self):
        return f"Melibu Script {self.script_type} with delay[us]: {self.delay_us}"


class OutputState(ABC):
    """ Class for defining an output state of a pin of the master device.

    Attributes:
        state (int): 1 for ON, 0 for OFF
    """
    _state = 0

    def __repr__(self):
        """ str: Gets the representation of the output state """
        lookup = {0: "OFF", 1: "ON"}
        return lookup[self.state]

    @property
    def state(self):
        """ int: Gets the state of the power supply """
        return self._state

    @state.setter
    def state(self, data):
        if int(data) not in (0, 1):
            raise ValueError(f"Expected a value of 0/1 or False/True; got {data!r}")
        self._state = int(data)


class DigitalPin(ABC):
    """ Class for defining a digital pin with a number.

    Attributes:
        number (int): Pin number.
    """
    _number = 0

    @property
    def number(self):
        """ int: Gets the pin number """
        return self._number

    @number.setter
    def number(self, data):
        self._number = int(data)


class PowerSupply(ScriptBase, OutputState):
    """ Class for defining commands that set the state of the power supply. """
    _script_type = 'Powersupply'

    def __init__(self, state, model=None):
        """ Constructor.

        Args:
            state (int): 1 for ON, 0 for OFF.
        """
        super().__init__(model=model)
        self.state = state

    def __str__(self):
        return ("Power supply: set state {state!r}"
                .format(state=self))


class DigitalOutput(ScriptBase, DigitalPin, OutputState):
    """ Class for defining commands that set the output state of a specific digital pin. """
    _script_type = 'Digitaloutput'

    def __init__(self, number, state, model=None):
        """ Constructor.

        Args:
            number (int): Pin number.
            state (int): 1 for ON, 0 for OFF.
        """
        super().__init__(model=model)
        self.number = number
        self.state = state

    def __str__(self):
        return ("Digital output: set state {state!r} for digital pin {number}"
                .format(state=self, number=self.number))


class DigitalInput(ScriptBase, DigitalPin):
    """ Class for defining commands that get the input state of a specific digital pin. """
    _script_type = 'Digitalinput'

    def __init__(self, number, model=None):
        """ Constructor.

        Args:
            number (int): Pin number.
        """
        super().__init__(model=model)
        self.number = number

    def __str__(self):
        return ("Digital input: get state for digital pin {number}"
                .format(number=self.number))


class SetBaudrate(ScriptBase):
    """ Class for defining a command to set the bus baudrate. """
    _script_type = "SetBaudrate"

    def __init__(self, baudrate, model=None):
        """ Constructor.

        Args:
            baudrate (int/None): Baudrate in bps, or None if the baudrate should be reset to the default.
        """
        super().__init__(model=model)
        self._baudrate = baudrate

    def __str__(self):
        return (f"Set bus baudrate to {'default' if self._baudrate is None else self._baudrate}.")

    @property
    def baudrate(self):
        """ int: Baudrate to set when this script command is processed """
        if self._baudrate is not None:
            return self._baudrate
        return self.model.bus_speed


class ExecuteScript(ScriptBase):
    """ Class for defining a command that executes a script.

    Note: Instances of this class will be replaced by the MeLiBu messages of the script in
    ParserApplication.postprocessing.
    """
    _script_type = "ExecuteScript"

    def __init__(self, script_path, model=None):
        """ Constructor.

        Args:
            script_path (pathlib.Path): Path to a MBDFSCR, absolute or relative to the MBDF.
        """
        super().__init__(model=model)
        self._path = None
        self.path = script_path

    @property
    def path(self):
        """ pathlib.Path: Path to a MBDFSCR, absolute or relative to the MBDF. """
        return self._path

    @path.setter
    def path(self, path):
        if not path.is_absolute():
            path = self.model.mbdf_path.parent / path
        path = path.resolve(strict=True)  # TODO catch and re-raise
        if not path.exists():
            raise FileNotFoundError(f"MBDFSCR file {path} in {self.script_type} command does not exist")
        self._path = path

    @property
    def delay_us(self):
        """ int: the delay in us for this frame """
        return super().delay_us

    @delay_us.setter
    def delay_us(self, value):
        if value != 0:
            raise ValueError("The delay <frame_time> for an ExecuteScript entry is not used so it shall be 0; "
                             f"got {value} us")
        self._delay_us = 0
