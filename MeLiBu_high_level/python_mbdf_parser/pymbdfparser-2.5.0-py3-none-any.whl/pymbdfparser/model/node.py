""" Module for the MasterNode and SlaveNode classes """
from collections import namedtuple
import re

from pymbdfparser.model.signal import Signal
from pymbdfparser.model.frame import CommandFrameMelibu1, FrameMelibu1, FrameMelibu2
from pymbdfparser.model.frame_base import FrameBase
from pymbdfparser.model.node_base import Node


class MasterNode(Node):
    """ Class for defining the master node's properties. """

    TYPE = 'MASTER'


class SlaveNode(Node):
    """ Class for defining the slave node's properties.

    Specifies the slave node's properties that the master node doesn't have.

    Attributes:
        bus_protocol (float): Shall be in the range of "1.00" to "99.99".
        configured_nad (int): Specifies the address for the identified slave node in the range from 4-63.
        product_id (ProductId): Object of the ProductId class, used to identify the product.
        response_error (Signal): Signal to be set whenever a frame that is transmitted or received by the slave
            node contains an error in the frame response.
        p2_min (int): The time between reception of the last frame on the bus and the slave node being able
            to provide data for a response. (in ms)
        m2s_ack (bool): The M2S_ACK specifies if the ACK must be sent by the slave within a M2S message and should be
            checked by the Master. True if the ACK must be checked, False otherwise.
        supported_frames (dict): Dictionary of all frames that are supported by the slave mapping frame name to
            Frame objects.
    """
    TYPE = 'SLAVE'
    _configured_nad = None

    def __init__(self, name, model=None):
        """ Constructor of the SlaveNode class.

        Args:
            name (str): The name of the node, which is unique in the cluster.
            model (MbdfModel): Parent model that contains this slave node
        """
        super().__init__(name, model=model)
        self._bus_protocol = None
        self._configured_nad = None
        self.product_id = None
        self._response_error = None
        self._p2_min = 0
        self._m2s_ack = None
        self._supported_frames = {}

    __hash__ = object.__hash__

    def __eq__(self, other):
        """ Tests two objects for equality based on attribute values.

        Args:
            other (SlaveNode): SlaveNode instance
        Returns:
            Whether both node's attributes and object types are equal or not.
        """
        if type(other) is type(self):
            return self.name == other.name and self.bus_protocol == other.bus_protocol and \
                   self.configured_nad == other.configured_nad and \
                   self.p2_min == other.p2_min and \
                   self.supported_frames == other.supported_frames
        return False

    @property
    def bus_protocol(self):
        """ Gets the bus protocol used by the slave node."""
        return self._bus_protocol

    @bus_protocol.setter
    def bus_protocol(self, protocol):
        self._bus_protocol = protocol

    @property
    def configured_nad(self):
        """ Gets the diagnostic address."""
        return self._configured_nad

    @configured_nad.setter
    def configured_nad(self, address):
        if self.bus_protocol is not None:
            if self.bus_protocol < 2.0 and not 4 <= address <= 63:
                raise ValueError("Invalid configured NAD: expected NAD in range 4-63, got {}".format(address))
            if self.bus_protocol >= 2.0 and not 4 <= address <= 254:
                raise ValueError("Invalid configured NAD: expected NAD in range 4-254, got {}".format(address))
        self._configured_nad = address

    @property
    def response_error(self):
        """ Gets the response_error signal."""
        return self._response_error

    @response_error.setter
    def response_error(self, response_error):
        if isinstance(response_error, Signal):
            self._response_error = response_error
        else:
            raise TypeError("Type of response error must be Signal; got %s." % response_error.__class__.__name__)

    @property
    def p2_min(self):
        """ Gets the P2_min value."""
        return self._p2_min

    @p2_min.setter
    def p2_min(self, p2_min):
        if not isinstance(p2_min, int):
            raise TypeError("Type of P2_min must be int; got %s." % p2_min.__class__.__name__)
        self._p2_min = p2_min

    @property
    def m2s_ack(self):
        """ Gets the M2S_ACK boolean value."""
        return self._m2s_ack

    @m2s_ack.setter
    def m2s_ack(self, boolean):
        self._m2s_ack = boolean

    @property
    def supported_signals(self):
        """ dict: dict of all signals available for this slave node, mapping name to Signal instance """
        signals = {}
        for _, frame_obj in self.supported_frames.items():
            if frame_obj.unsorted_signals:
                for signal_obj in frame_obj.unsorted_signals:
                    signals[signal_obj.signal.name] = (signal_obj.signal)
            if isinstance(frame_obj, FrameMelibu1):
                if isinstance(frame_obj.sub_address_signal, Signal):
                    signals[frame_obj.sub_address_signal.name] = frame_obj.sub_address_signal
                if isinstance(frame_obj, CommandFrameMelibu1) and isinstance(frame_obj.ext_instruction_signal, Signal):
                    signals[frame_obj.ext_instruction_signal.name] = frame_obj.ext_instruction_signal
            elif isinstance(frame_obj, FrameMelibu2):
                if isinstance(frame_obj.instruction_word_signal, Signal):
                    signals[frame_obj.instruction_word_signal.name] = frame_obj.instruction_word_signal
        return signals

    @property
    def supported_frames(self):
        """ Gets the supported_frames dictionary."""
        return self._supported_frames

    def add_supported_frame(self, frame):
        """ Adds a supported frame to the supported_frames dictionary.

        Args:
            frame (FrameBase): Instance with FrameBase as base class to be added to the supported_frames dictionary.
        Raises:
            TypeError: The type of the passed frame argument is wrong.
        """
        if not isinstance(frame, FrameBase):
            raise TypeError("Type must be FrameBase; got %s." % frame.__class__.__name__)
        self._supported_frames[frame.name] = frame

    class ProductId:
        """ Class for defining a slave node's product ID.

        Attributes:
            MIN_PRODUCT_ID (LimitProductId): The product ID with the minimum allowed values.
            MAX_PRODUCT_ID (LimitProductId): The product ID with the maximum allowed values.
            supplier (int): Supplier ID of the product ID.
            function (int): Function ID of the product ID.
            variant (int): Variant parameter of the product ID. The default value 0.
        """
        LimitProductId = namedtuple('LimitProductId', 'supplier function variant')
        MIN_PRODUCT_ID = LimitProductId(0, 0, 0)
        MAX_PRODUCT_ID = LimitProductId(0x7FFF, 0xFFFF, 255)
        _supplier = None
        _function = None
        _variant = None

        def __init__(self, supplier, function, variant=0):
            self.supplier = supplier
            self.function = function
            self.variant = variant

        def __eq__(self, other):
            """ Tests two objects for equality based on attribute values.

            Args:
                other (ProductId): ProductId instance
            Returns:
                bool: Whether both dict attributes and object types are equal or not.
            """
            if type(other) is type(self):
                return self.__dict__ == other.__dict__
            return False

        @property
        def supplier(self):
            """ Gets the supplier ID."""
            return self._supplier

        @property
        def function(self):
            """ Gets the function ID."""
            return self._function

        @property
        def variant(self):
            """ Gets the variant paramter."""
            return self._variant

        @supplier.setter
        def supplier(self, supplier):
            if not isinstance(supplier, int):
                raise TypeError("Type of supplier ID must be int; got %s." % supplier.__class__.__name__)
            if supplier < self.MIN_PRODUCT_ID.supplier or supplier > self.MAX_PRODUCT_ID.supplier:
                raise ValueError("Supplier ID {} is not in range of {} to {}."
                                 .format(supplier,
                                         hex(self.MIN_PRODUCT_ID.supplier),
                                         hex(self.MAX_PRODUCT_ID.supplier)))
            self._supplier = supplier

        @function.setter
        def function(self, function):
            if not isinstance(function, int):
                raise TypeError("Type of function ID must be int; got %s." % function.__class__.__name__)
            if function < self.MIN_PRODUCT_ID.function or function > self.MAX_PRODUCT_ID.function:
                raise ValueError("Function ID {} is not in range of {} to {}."
                                 .format(function,
                                         hex(self.MIN_PRODUCT_ID.function),
                                         hex(self.MAX_PRODUCT_ID.function)))
            self._function = function

        @variant.setter
        def variant(self, variant):
            if not isinstance(variant, int):
                raise TypeError("Type of variant parameter must be int; got %s." % variant.__class__.__name__)
            if variant < self.MIN_PRODUCT_ID.variant or variant > self.MAX_PRODUCT_ID.variant:
                raise ValueError("Variant ID {} is not in range of {} to {}."
                                 .format(variant,
                                         hex(self.MIN_PRODUCT_ID.variant),
                                         hex(self.MAX_PRODUCT_ID.variant)))
            self._variant = variant


class BroadcastNode(SlaveNode):
    """ Class representing destination of a broadcast message as a node.

    Four instances shall exist per MBDF model (broadcast 0...3)."""

    TYPE = 'BROADCAST'

    def __init__(self, *args, **kwargs):
        """ Constructor of the BroadcastNode class. """
        super().__init__(*args, **kwargs)
        self._listeners = set()

    @property
    def name(self):
        """ str: Broadcast node name. """
        return self._name

    @name.setter
    def name(self, name):
        match = re.fullmatch(r"Broadcast(?P<nad>[0-3])", name)
        if match:
            self._name = name
        else:
            raise ValueError(f"Expected a name that matches the regexp Broadcast[0-3]; got {name!r}")

    @property
    def configured_nad(self):
        """ int: Configured broadcast NAD. """
        return int(self.name[-1])

    @configured_nad.setter
    def configured_nad(self, address):
        if 0 <= address <= 3:
            self._name = f"Broadcast{address}"
        else:
            raise ValueError(f"Broadcast node's NAD must be in range 0...3; got {address}")

    @property
    def m2s_ack(self):
        """ Always returns False (ACK not valid for broadcast). """
        return False

    @property
    def listeners(self):
        """ frozenset: SlaveNodes that subscribe to broadcast messages on this NAD. """
        return frozenset(self._listeners)

    def add_listener(self, node):
        """ Adds slave node as listener to the broadcast. """
        if node.TYPE == "SLAVE":
            self._listeners.add(node)
        else:
            raise ValueError("Broadcast listeners may only be non-broadcast SlaveNodes; "
                             f"got {node.__class__.__name__}")

    @property
    def p2_min(self):
        """ int: Worst-case slave node response time. """
        return max({node.p2_min for node in self.listeners})

    @property
    def supported_frames(self):
        """ dict: frames supported by all broadcast listeners """
        if len(self.listeners) == 0:
            return {}
        frames = set.intersection(*map(lambda listener: set(listener.supported_frames.values()), self.listeners))
        return {frame.name: frame for frame in frames}

    def add_supported_frame(self, frame):
        raise NotImplementedError("Supported broadcast frames are defined by the broadcast listeners.")
