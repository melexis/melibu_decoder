""" Module for the SignalRepresentation and SignalEncodingType classes """
from abc import ABC
import re

NUMBER_REGEX = re.compile(
    r'^[-+]?(?:(?:(?:[1-9](?:_?\d)*|0+(_?0)*)|(?:0[bB](?:_?[01])+)'
    r'|(?:0[oO](?:_?[0-7])+)|(?:0[xX](?:_?[0-9a-fA-F])+))'
    r'|(?:(?:(?:\d(?:_?\d)*)?(?:\.(?:\d(?:_?\d)*))|(?:\d(?:_?\d)*)\.)'
    r'|(?:(?:(?:\d(?:_?\d)*)|(?:(?:\d(?:_?\d)*)?(?:\.(?:\d(?:_?\d)*))'
    r'|(?:\d(?:_?\d)*)\.))(?:[eE][-+]?(?:\d(?:_?\d)*)))))$',
    re.UNICODE)


class SignalEncodingType:
    """ Class for bundling encoding types.

    Attributes:
        name (str): Name of the signal encoding type.
        encodings (list): List of Encoding objects associated with each other.
    """

    def __init__(self, name):
        """ Constructor of SignalEncodingType class

        Args:
            name (str): Name of the signal encoding type.
        """
        self._name = name
        self._encodings = []

    def __eq__(self, other):
        """ Tests two objects for equality based on attribute values.

        Args:
            other (SignalRepresentation): SignalRepresentation instance.
        Returns:
            bool: Whether both dict attributes and object types are equal or not.
        """
        if type(other) is type(self):
            return self.__dict__ == other.__dict__
        return False

    @property
    def name(self):
        """ Gets the name."""
        return self._name

    @property
    def encodings(self):
        """ Gets the list of encodings."""
        return self._encodings

    def add_encoding(self, encoding):
        """ Adds an encoding to the list of encodings.

        Args:
            encoding (Encoding): Encoding instance to be added to the list of encodings.
        Raises:
            TypeError: The type of the passed argument is wrong.
        """
        if not isinstance(encoding, Encoding):
            raise TypeError("Type must be Encoding but encountered %s." % encoding.__class__)
        self._encodings.append(encoding)

    def encode(self, readable_value):
        """ Encodes a human readable value into a signal bus value.

        Args:
            readable_value (str): The human readable value to be encoded.

        Returns:
            int|None: The encoded signal value if encoding is possible; None otherwise.
        """
        for encoding in self.encodings:
            result = encoding.encode(readable_value)
            if result is not None:
                return result

    def decode(self, bus_value):
        """ Decodes a signal bus value into a human readable value.

        Args:
            bus_value (int): The signal bus value to be decoded.

        Returns:
            str|None: Decoded human readable value if decoding is possible; None otherwise.
        """
        for encoding in self.encodings:
            result = encoding.decode(bus_value)
            if result is not None:
                return result


class Encoding(ABC):
    """ Abstract class for defining an encoding, which provides representation and scaling properties of signals.

    Attributes:
        ENCODING (str|NoneType): Specifies the encoding type.
    """
    ENCODING = None

    def __eq__(self, other):
        """ Tests two objects for equality based on attribute values.

        Args:
            other (Encoding): Encoding instance
        Returns:
            Whether both dict attributes and object types are equal or not.
        """
        if type(other) is type(self):
            return self.__dict__ == other.__dict__
        return False

    @staticmethod
    def check_in_range(value):
        """ Checks if the given number is within the allowed range.

        Args:
            value (int/float): Number to check value of

        Returns:
            int/float: Number with valid value

        Raises:
            ValueError: Expected value in range of 0 to 65535; got an invalid value
        """
        if 0 <= value <= 65535:
            return value
        raise ValueError(f"Expected value in range of 0 to 65535; got {value}")


class LogicalEncoding(Encoding):
    """ Class for defining a logical encoding.

    Attributes:
        value (float): Numeric value of the signal in range of 0 to 65535..
        text (str): Textual meaning of the signal bus value.
    """
    ENCODING = 'logical_value'

    def __init__(self, value, text=None):
        self._value = self.check_in_range(value)
        self._text = text

    @property
    def value(self):
        """ Gets the numeric value."""
        return self._value

    @property
    def text(self):
        """ Gets the textual value."""
        return self._text

    def encode(self, readable_value):
        """ Encodes a human readable value into a signal bus value.

        Args:
            readable_value (str): The human readable value to be encoded.

        Returns:
            int|None: The encoded signal value if encoding is possible; None otherwise.
        """
        if readable_value == self.text:
            return self.value
        return None

    def decode(self, bus_value):
        """ Decodes a signal bus value into a human readable value.

        Args:
            bus_value (int): The signal bus value to be decoded.

        Returns:
            str|None: Decoded human readable value if decoding is possible; None otherwise.
        """
        if bus_value == self.value:
            return self.text
        return None


class PhysicalEncoding(Encoding):
    """ Class for defining a physical encoding with a min, max, scale, and offset value.

    Attributes:
        min_value (float): Minimum value of the signal in range of 0 to 65535.
        max_value (float): Maximum value of the signal in range of 0 to 65535 and greater than or equal to  min_value.
        scale (float): Factor for the signal's value.
        offset (float): Offset for the signal's value.
        text (str): Unit, e.g. "Volt".
    """
    ENCODING = 'physical_value'

    def __init__(self, min_value, max_value, scale, offset, text=""):
        self._min_value = self.check_in_range(min_value)
        self._max_value = self.check_in_range(max_value)
        self._scale = scale
        self._offset = offset
        self._text = text
        if self.min_value > self.max_value:
            raise ValueError(f"The min_value ({min_value}) is greater than the max_value ({max_value}).")

    @property
    def min_value(self):
        """ Gets the minimum value."""
        return self._min_value

    @property
    def max_value(self):
        """ Gets the maximal value."""
        return self._max_value

    @property
    def scale(self):
        """ Gets the value of the scale."""
        return self._scale

    @property
    def offset(self):
        """ Gets the value of the offset."""
        return self._offset

    @property
    def text(self):
        """ Gets the textual value."""
        return self._text

    def encode(self, readable_value):
        """ Encodes a human readable value into a signal bus value.

        Args:
            readable_value (str|int|float): The human readable value to be encoded.

        Returns:
            int|None: The encoded signal value if encoding is possible; None otherwise.

        Raises:
            ValueError: Invalid readable value.
        """
        value = readable_value
        if isinstance(value, str):
            value = value.split(' ')[0]  # drop text, which has to be separated by a space
            match = NUMBER_REGEX.match(value)
            if match is None:
                raise ValueError(f"Cannot encode {readable_value!r} as it is not a valid human readable signal value. "
                                 "Text shall be separated from the number by a space.")
            number_str = match[0].lower()
            if 'x' in number_str:
                value = int(number_str, 16)
            elif 'b' in number_str:
                value = int(number_str, 2)
            elif 'o' in number_str:
                value = int(number_str, 8)
            else:
                value = float(number_str)
        value = int(round((value - self.offset) / self.scale))
        if self.min_value <= value <= self.max_value:
            return value

    def decode(self, bus_value):
        """ Decodes a signal bus value into a human readable value.

        Args:
            bus_value (int): The signal bus value to be decoded.

        Returns:
            str|None: Decoded human readable value if decoding is possible; None otherwise.
        """
        if self.min_value <= bus_value <= self.max_value:
            value = round((self.scale * bus_value) + self.offset, 5)
            return f"{value} {self.text}".rstrip()
