"""Python module with the interface definition for a device class.

Copyright Melexis N.V.

This product includes software developed at Melexis N.V. (https://www.melexis.com).

Melexis N.V. has provided this code according to LICENSE file attached to repository
"""
from abc import ABC, abstractmethod


class DeviceInterface(ABC):
    """Abstract base class with methods to be defined by all device classes."""

    @abstractmethod
    def open_all(self, port):
        """Open and initiate the connection to the device and it's sub devices/controls.

        Args:
            port (str): port to be used for communication.
        """

    @abstractmethod
    def close_all(self):
        """Terminate the connection to the device."""

    @property
    def is_opened(self):
        """bool: True if connection to device is established."""

    @abstractmethod
    def bind_hw_control(self, control_type, control_obj):
        """Bind a hardware control object to this device.

        The hardware control object(s) are used for communication from
        PC to some hardware device such as MUM, PTC, FPGA, ...

        Args:
            control_type (str): identifier string for the hardware control object.
            control_obj (ControlInterface): new device hardware control object to bind to.
        """

    @abstractmethod
    def unbind_hw_control(self, control_type):
        """Unbind a hardware control object from this device.

        Args:
            control_type (str): identifier string for the hardware control object.
        """

    @abstractmethod
    def get_hw_control(self, control_type):
        """Get the hardware control object from this device.

        Args:
            control_type (str): identifier string for the hardware control object.

        Returns:
            ControlInterface: requested hardware control object.
        """

    @abstractmethod
    def enum_hw_controls(self):
        """Get all the identifiers for all the hw control items (recursive).

        Returns:
            list of str: list of hw control identifiers for this device
        """
