"""Python module with the interface definition for a PPM bus class.

Copyright Melexis N.V.

This product includes software developed at Melexis N.V. (https://www.melexis.com).

Melexis N.V. has provided this code according to LICENSE file attached to repository
"""
from abc import ABC, abstractmethod
from pymlxabc.bus_interface import BusInterface


class PpmBusInterface(BusInterface, ABC):
    """Abstract base class with methods to be defined by all PPM bus classes."""
    _type_descriptor = 'ppm'

    @abstractmethod
    def send_enter_ppm_pattern(self, pattern_time):
        """Send the enter PPM mode pattern on the bus.

        Args:
            pattern_time (int): time to transmit enter PPM mode pattern (in ms).
        """

    @abstractmethod
    def send_calibration_frame(self):
        """Send the calibration frame on the bus."""

    @abstractmethod
    def do_unlock_session(self, request_ack, mlx81330_49_fix):
        """Send the unlock session on the bus.

        Args:
            request_ack (bool): en/disable the usage/requesting of slave ack messages during this session.
            mlx81330_49_fix (bool): en/disable fix for JIRA MLX81330-49.

        Returns:
            int: the project id as reported by the IC. In broadcast mode, this id is invalid as there is no reporting.
        """

    @abstractmethod
    def do_prog_keys_session(self, request_ack, mlx81330_49_fix, prog_keys):
        """Send the programming keys session on the bus.

        Args:
            request_ack (bool): en/disable the usage/requesting of slave ack messages during this session.
            mlx81330_49_fix (bool): en/disable fix for JIRA MLX81330-49.
            prog_keys (list of ints): the programming keys to be sent.
        """

    @abstractmethod
    def do_ram_programming_session(self, request_ack, mlx81330_49_fix, ram_program):
        """Send the RAM programming session on the bus.

        Args:
            request_ack (bool): en/disable the usage/requesting of slave ack messages during this session.
            mlx81330_49_fix (bool): en/disable fix for JIRA MLX81330-49.
            ram_program (bytearray): the RAM program to be sent.
        """

    @abstractmethod
    def do_flash_programming_session(self, request_ack, mlx81330_49_fix, block_erase, flash_program):
        """Send the flash programming session on the bus.

        Args:
            request_ack (bool): en/disable the usage/requesting of slave ack messages during this session.
            mlx81330_49_fix (bool): en/disable fix for JIRA MLX81330-49.
            block_erase (bool): en/disable block erase timeout.
            flash_program (bytearray): the flash program to be sent.
        """

    @abstractmethod
    def do_eeprom_programming_session(self, request_ack, mlx81330_49_fix, eeprom_offset, eeprom_data):
        """Send the EEPROM programming session on the bus.

        Args:
            request_ack (bool): en/disable the usage/requesting of slave ack messages during this session.
            mlx81330_49_fix (bool): en/disable fix for JIRA MLX81330-49.
            eeprom_offset (int): offset to start programming in the EEPROM (must be page aligned).
            eeprom_data (bytearray): the EEPROM data to be written (must be page aligned).
        """

    @abstractmethod
    def do_flash_cs_programming_session(self, request_ack, mlx81330_49_fix, flash_cs_data):
        """Send the flash CS programming session on the bus.

        Args:
            request_ack (bool): en/disable the usage/requesting of slave ack messages during this session.
            mlx81330_49_fix (bool): en/disable fix for JIRA MLX81330-49.
            flash_cs_data (bytearray): the flash CS data to be sent.
        """

    @abstractmethod
    def do_flash_crc_session(self, mlx81330_49_fix, flash_length):
        """Send a flash CRC read session command.

        Args:
            mlx81330_49_fix (bool): en/disable fix for JIRA MLX81330-49.
            flash_length (int): number of bytes to calculate the CRC for; calculation always starts
                at address 0; will be page aligned.

        Returns:
            int: the flash CRC value (24-bit BIST)
        """

    @abstractmethod
    def do_eeprom_crc_session(self, mlx81330_49_fix, eeprom_offset, eeprom_length):
        """Send a EEPROM CRC read session command.

        Args:
            mlx81330_49_fix (bool): en/disable fix for JIRA MLX81330-49.
            eeprom_offset (int): number of bytes offset from start of EEPROM to start calculating.
            eeprom_length (int): number of bytes to calculate the CRC for; shall be page aligned.

        Returns:
            int: the EEPROM CRC value (16-bit CRC CCIT)
        """

    @abstractmethod
    def do_flash_cs_crc_session(self, mlx81330_49_fix, flash_cs_length):
        """Send a flash CS CRC read session command.

        Args:
            mlx81330_49_fix (bool): en/disable fix for JIRA MLX81330-49.
            flash_cs_length (int): number of bytes to calculate the CRC for; shall be page aligned.

        Returns:
            int: the flash CS CRC value (16-bit CRC CCIT)
        """

    @abstractmethod
    def do_chip_reset_session(self, request_ack, mlx81330_49_fix):
        """Send the chip reset session on the bus.

        Args:
            request_ack (bool): en/disable the usage/requesting of slave ack messages during this session.
            mlx81330_49_fix (bool): en/disable fix for JIRA MLX81330-49.

        Returns:
            int: the project id as reported by the IC. In broadcast mode, this id is invalid as there is no reporting.
        """
