"""Python module with the interface definition for a fast bus class.

Copyright Melexis N.V.

This product includes software developed at Melexis N.V. (https://www.melexis.com).

Melexis N.V. has provided this code according to LICENSE file attached to repository
"""
from abc import ABC, abstractmethod
from pymlxabc.bus_interface import BusInterface


class FastBusInterface(BusInterface, ABC):
    """Abstract base class with methods to be defined by all fast bus classes."""
    _type_descriptor = 'fast'

    @property
    @abstractmethod
    def fast_voltage(self):
        """int: FAST protocol bus voltage level (in V)."""

    @fast_voltage.setter
    @abstractmethod
    def fast_voltage(self, value):
        ...

    @abstractmethod
    def send_message(self, en_sof, exit_fast, expect_response, data):
        """Send a fast message on the bus.

        Args:
            en_sof (bool): True = start the frame with a SOF pulse.
            exit_fast (bool): True = request an exit from fast protocol.
            expect_response (bool): True = we are expecting a slave response.
            data (byte array): a list with the data to be transmitted.
        """

    @abstractmethod
    def receive_message(self):
        """Receive a fast message on the bus.

        Returns:
            byte array: the received data bytes
        """
