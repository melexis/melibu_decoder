"""Python module with the interface definition for a power output class.

Copyright Melexis N.V.

This product includes software developed at Melexis N.V. (https://www.melexis.com).

Melexis N.V. has provided this code according to LICENSE file attached to repository
"""
from abc import ABC, abstractmethod
from pymlxabc.device_interface import DeviceInterface


class PowerOutInterface(DeviceInterface, ABC):
    """Abstract base class with methods to be defined by all power output classes."""

    @abstractmethod
    def power_up(self, voltage):
        """Turns on the power output and sets the voltage level.

        Args:
            voltage (int): voltage level to configured.
        """

    @abstractmethod
    def power_down(self):
        """Turns off the power output."""
