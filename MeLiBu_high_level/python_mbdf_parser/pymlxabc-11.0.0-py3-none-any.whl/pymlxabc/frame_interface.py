"""Python module with the interface definition for a frame class.

Copyright Melexis N.V.

This product includes software developed at Melexis N.V. (https://www.melexis.com).

Melexis N.V. has provided this code according to LICENSE file attached to repository
"""
from abc import ABC, abstractmethod


class FrameInterface(ABC):
    """Abstract base class with methods to be defined by all Frame classes."""

    @property
    def master_to_slave(self):
        """bool: True for master 2 slave, False for slave 2 master."""

    @master_to_slave.setter
    @abstractmethod
    def master_to_slave(self, value):
        pass

    @property
    def baudrate(self):
        """int: baudrate for this frame."""

    @baudrate.setter
    @abstractmethod
    def baudrate(self, value):
        pass
