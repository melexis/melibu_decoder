"""Python module with the interface definition for a lin bus class.

Copyright Melexis N.V.

This product includes software developed at Melexis N.V. (https://www.melexis.com).

Melexis N.V. has provided this code according to LICENSE file attached to repository
"""
from abc import ABC, abstractmethod
from pymlxabc.bus_interface import BusInterface


class LinBusInterface(BusInterface, ABC):
    """Abstract base class with methods to be defined by all lin bus classes."""
    _type_descriptor = 'lin'

    @abstractmethod
    def send_wake_up_pulse(self, pulse_time):
        """Network management: send a wakeup pulse on the bus.

        Any node in a sleeping LIN cluster may request a wake up, by transmitting a wake up
        signal. The wake up signal is started by forcing the bus to the dominant state for 250
        us to 5 ms, and is valid with the return of the bus signal to the recessive state.

         - see lin v2.0 - 5.1 wake up
         - see lin v2.1 - 2.6.2 wake up
         - see lin v2.2a - 2.6.2 wake up

        Args:
            pulse_time (int): wake up pulse dominant bus level time (in us).
        """

    @abstractmethod
    def handle_message_on_bus(self, frame):
        """Transmits a frame on the lin bus.

        Transmit or receive a lin frame on the lin bus.

        Args:
            frame (LinFrameInterface): frame to be transferred.

        Returns:
            LinFrameInterface: transferred frame.
        """
