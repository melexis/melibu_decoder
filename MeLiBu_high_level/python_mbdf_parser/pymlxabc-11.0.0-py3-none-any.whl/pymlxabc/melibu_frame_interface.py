"""Python module for handling melibu frames.

Copyright Melexis N.V.

This product includes software developed at Melexis N.V. (https://www.melexis.com).

Melexis N.V. has provided this code according to LICENSE file attached to repository
"""
from abc import ABC, abstractmethod
from pymlxabc.frame_interface import FrameInterface


class MelibuFrameInterfaceBase(FrameInterface, ABC):
    """Base class for representing a Melibu frame."""

    @property
    @abstractmethod
    def function_type(self):
        """str: function type of this frame."""

    @property
    @abstractmethod
    def check_ack(self):
        """bool: True if the slave acknowledge needs to be checked."""

    @check_ack.setter
    @abstractmethod
    def check_ack(self, value):
        pass

    @property
    @abstractmethod
    def slave_address(self):
        """int: the slave address of this frame."""

    @slave_address.setter
    @abstractmethod
    def slave_address(self, value):
        pass

    @property
    @abstractmethod
    def payload(self):
        """bytearray: the payload of this frame."""

    @payload.setter
    @abstractmethod
    def payload(self, data):
        pass


class MelibuFrameInterface(MelibuFrameInterfaceBase):
    """Class that represents a standard Melibu 1.x frame."""

    @property
    @abstractmethod
    def sub_address(self):
        """int: the sub address for this frame."""

    @sub_address.setter
    @abstractmethod
    def sub_address(self, value):
        pass

    @property
    @abstractmethod
    def mode(self):
        """int: the mode setting for this frame."""

    @mode.setter
    @abstractmethod
    def mode(self, value):
        pass

    @property
    @abstractmethod
    def ext_instruction(self):
        """int: the ext instruction for this frame."""

    @ext_instruction.setter
    @abstractmethod
    def ext_instruction(self, value):
        pass


class Melibu2FrameInterface(MelibuFrameInterfaceBase):
    """Class that represents a standard Melibu 2.x frame."""

    @property
    @abstractmethod
    def pl_length(self):
        """int: the payload length parameter, which depends on the function type."""

    @pl_length.setter
    @abstractmethod
    def pl_length(self, value):
        pass

    @property
    @abstractmethod
    def instruction_word(self):
        """int: the instruction word for this frame."""

    @instruction_word.setter
    @abstractmethod
    def instruction_word(self, value):
        pass

    @property
    @abstractmethod
    def i_bit(self):
        """int: 1 if the instruction word must be added before the payload, 0 otherwise."""

    @i_bit.setter
    @abstractmethod
    def i_bit(self, value):
        pass
