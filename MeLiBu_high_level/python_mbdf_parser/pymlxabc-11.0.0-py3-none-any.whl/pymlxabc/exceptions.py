"""Python module which provides all the pymlxabc exceptions.

Copyright Melexis N.V.

This product includes software developed at Melexis N.V. (https://www.melexis.com).

Melexis N.V. has provided this code according to LICENSE file attached to repository
"""
from pymlxexceptions import PyMlxBaseException


class PyMlxAbcBaseException(PyMlxBaseException):
    """Custom base exception for the pymlxabc module."""


class DeviceManagerException(PyMlxAbcBaseException):
    """Custom exception class for the DeviceManager class."""
