"""Python module with the interface definition for a programmer class.

Copyright Melexis N.V.

This product includes software developed at Melexis N.V. (https://www.melexis.com).

Melexis N.V. has provided this code according to LICENSE file attached to repository
"""
from abc import ABC, abstractmethod
from pymlxabc.device_interface import DeviceInterface


class ProgrammerInterface(DeviceInterface, ABC):
    """Abstract base class with methods to be defined by all programmer classes."""

    @abstractmethod
    def contact_test(self):
        """Execute a contact test."""

    @abstractmethod
    def erase_flash(self):
        """Erase the flash of the chip."""

    @abstractmethod
    def write_flash(self, app_hex):
        """Upload a new application to the flash memory of a chip.

        Args:
            app_hex (str): string containing the path to the application hex file.
        """

    @abstractmethod
    def verify_flash(self, app_hex):
        """Verify the flash content of a chip.

        Args:
            app_hex (str): string containing the path to the application hex file.
        """

    @abstractmethod
    def verify_flash_by_crc(self, app_hex):
        """Verify the flash content of a chip using the HW BIST module.

        Args:
            app_hex (str): string containing the path to the application hex file.
        """

    @abstractmethod
    def read_nvram(self, start_addr, nr_bytes):
        """Read nvram content.

        Args:
            start_addr (int): address to start reading data from.
            nr_bytes (int): number of bytes to read.

        Returns:
            bytearray: bytes which where read.
        """

    @abstractmethod
    def write_nvram(self, start_addr, data):
        """Write nvram content.

        Args:
            start_addr (int): address to start writing data from.
            data (bytearray): data to be written to the memory.
        """

    @abstractmethod
    def verify_nvram(self, start_addr, data):
        """Verify the nvram content.

        Args:
            start_addr (int): address to start verifying data from.
            data (bytearray): data to be verified in the memory.
        """

    @abstractmethod
    def read_nvram_to_hex(self, nvram_hex):
        """Read the nvram content and write to a hex file.

        Args:
            nvram_hex (str): string containing the path to the nvram hex file to be created.
        """

    @abstractmethod
    def write_nvram_from_hex(self, nvram_hex):
        """Write nvram memory using a given hex file.

        Args:
            nvram_hex (str): string containing the path to the nvram hex file.
        """

    @abstractmethod
    def verify_nvram_by_hex(self, nvram_hex):
        """Verify the nvram content with the content from a hex file.

        Args:
            nvram_hex (str): string containing the path to the nvram hex file.
        """
