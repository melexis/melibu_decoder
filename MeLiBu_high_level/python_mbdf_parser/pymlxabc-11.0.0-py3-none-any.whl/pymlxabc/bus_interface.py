"""Python module with the interface definition for a generic bus class.

Copyright Melexis N.V.

This product includes software developed at Melexis N.V. (https://www.melexis.com).

Melexis N.V. has provided this code according to LICENSE file attached to repository
"""
from abc import ABC, abstractmethod
from pymlxabc.device_interface import DeviceInterface


class BusInterface(DeviceInterface, ABC):
    """Abstract base class with methods to be defined by all bus classes."""

    def __init__(self, bus_type='', **kwargs):
        """Class constructor.

        Args:
            bus_type (str): string describing the type of the bus (lin, ppm, melibu, ...).
        """
        super().__init__(**kwargs)
        if bus_type:
            self._type_descriptor = bus_type

    def get_bus_type(self):
        """Read out the type of the bus which this interface provides.

        Returns:
            str: A string describing the bus type.
        """
        return self._type_descriptor

    @abstractmethod
    def get_time_since_last_bus_action(self):
        """Return the time between now and the last bus action.

        Returns:
            DateTime: The time difference from the last bus activity till now.
        """

    @abstractmethod
    def reset_last_bus_action_time(self):
        """Reset the last bus action time to the current time."""

    @abstractmethod
    def get_bus_state(self):
        """Read out the current bus state.

        Returns:
            str: A string describing the current bus state.
        """
