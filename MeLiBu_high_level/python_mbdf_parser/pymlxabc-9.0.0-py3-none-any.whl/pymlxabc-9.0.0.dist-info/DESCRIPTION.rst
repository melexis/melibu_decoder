Melexis Python Abstract Base Classes to be used in other projects and make sure we have consistant interfaces.

