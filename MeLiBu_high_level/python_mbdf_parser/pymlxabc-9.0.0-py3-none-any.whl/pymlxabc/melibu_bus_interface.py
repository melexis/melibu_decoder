""" MelibuBusInterface
Python module with the interface definition for a melibu bus class

Copyright Melexis N.V.

This product includes software developed at Melexis N.V. (https://www.melexis.com).

Melexis N.V. has provided this code according to LICENSE file attached to repository
"""
from abc import ABC, abstractmethod
from pymlxabc.bus_interface import BusInterface


class MelibuBusInterface(BusInterface, ABC):
    """ Abstract base class with methods to be defined by all melibu bus classes """
    _type_descriptor = 'melibu'

    @property
    def melibu_major_version(self):
        """ int: Melibu major version number to be used """

    @melibu_major_version.setter
    @abstractmethod
    def melibu_major_version(self, value):
        pass

    @property
    def start_address(self):
        """ int: Start address used for the network """

    @start_address.setter
    @abstractmethod
    def start_address(self, value):
        pass

    @property
    def number_slaves(self):
        """ int: Number of connected nodes in the network """

    @number_slaves.setter
    @abstractmethod
    def number_slaves(self, value):
        pass

    @property
    def baudrate(self):
        """ int: the MeLiBu baudrate[bps] used by the master """

    @baudrate.setter
    @abstractmethod
    def baudrate(self, value):
        pass

    @property
    def breakbits(self):
        """ int: MeLiBu breakfield length[bit] of the current application """

    @breakbits.setter
    @abstractmethod
    def breakbits(self, value):
        pass

    @property
    def trx_delay_us(self):
        """ int: The interframe delay[us] of the current application to wait after each message """

    @trx_delay_us.setter
    @abstractmethod
    def trx_delay_us(self, value):
        pass

    @abstractmethod
    def send_wake_up_pulse(self):
        """ Network management: send a wakeup pulse on the bus.

        Any node in a sleeping Melibu cluster may request a wake up, by transmitting a wake up
        signal.
        """

    @abstractmethod
    def handle_message_on_bus(self, frame):
        """ Transmits a frame on the melibu bus.

        Transmit or receive a melibu frame on the melibu bus.

        Args:
            frame (MelibuFrameInterface): frame to be transferred.

        Returns:
            MelibuFrameInterface: transferred frame.
        """

    @abstractmethod
    def autoaddressing(self, save_nad, frame_delay_ms):
        """ handles the auto-addressing sequence

        Args:
            save_nad (bool): store NAD if supported by application
            frame_delay_ms (int): time to wait between a M2S and S2M frame
        """

    @abstractmethod
    def handle_free_data_on_bus(self, tx_len, rx_len, data):
        """ Transmits free data on the melibu bus.

        Transmit or receive free data on the melibu bus.

        Args:
            tx_len (integer): number of bytes to send.
            rx_len (integer): number of bytes to receive.
            data (bytearray): data to send.

        Returns:
            bytearray: the response message data received.
        """

    @abstractmethod
    def process_mum_script_data(self, data, do_loop, mode, baudrate):
        """ process MUM melibu script data.

        Args:
            data (dict): data to be transferred.
            do_loop (bool): looping script or stop after execution.
            mode (int): melibu mode to be used(normal, extended)
            baudrate (int): baudrate index to use a defined baudrate for the script execution

        Returns:
            bytearray: prepared data for MUM.
        """

    @abstractmethod
    def upload_mum_script(self, data):
        """ upload and start mum melibu script.

        Args:
            data (bytearray): data to be transferred.
        """

    @abstractmethod
    def stop_script(self):
        """ stop the execution of the melibu script """

    @abstractmethod
    def start_tracing(self):
        """ start melibu tracing """

    @abstractmethod
    def get_tracing_data(self):
        """ get recorded melibu data """

    @abstractmethod
    def stop_tracing(self):
        """ stop melibu tracing """

    @abstractmethod
    def send_epm(self, epm_delay):
        """ Send a enter programming mode frame on the bus

        Args:
            epm_delay (int): delay to wait after sending EPM command in ms
        """

    @abstractmethod
    def erase_flash(self, node_address, pre_write_flash):
        """ Erase the complete Flash via Bootloader

        Args:
            node_address (int): slave address to erase
            pre_write_flash (bool): perform flash pre-write after erase
        """

    @abstractmethod
    def erase_flash_sector(self, node_address, sector_to_erase, pre_write_flash):
        """ handles the erasing of single flash sector via bootloader

        Args:
            melibu_major_version (int): Melibu version to be used
            node_address (int): address which will be programmed (0 -> program all)
            sector_to_erase (int): sector to erase
            pre_write_flash (bool): perform flash pre-write after erase
        """

    @abstractmethod
    def erase_eeprom(self, node_address):
        """ Erase the EEPROM application area via Bootloader

        Args:
            node_address (int): slave address to erase
        """

    @abstractmethod
    def program_ram(self,
                    node_address,
                    data,
                    ram_addr_write,
                    ram_addr_exec):
        """ Program the RAM via Bootloader

        Args:
            node_address (int): slave address to program
            data (bytearray): bytearray to be programmed in RAM
            ram_addr_write (int): address to write RAM program
            ram_addr_exec (int): address to execute RAM program from
        """

    @abstractmethod
    def program_flash(self, node_address, data):
        """ Program the Flash via Bootloader

        Args:
            node_address (int): slave address to program
            data (bytearray): bytearray with the complete hex file content
        """

    @abstractmethod
    def program_flash_sector(self,
                             node_address,
                             sector_to_program,
                             data,
                             flash_start_addr):
        """ Program the Flash via Bootloader

        Args:
            node_address (int): slave address to program
            sector_to_program (int): sector to program
            data (bytearray): bytearray with the complete hex file content
            flash_start_addr (int): flash start address
        """

    @abstractmethod
    def program_eeprom(self, node_address, data):
        """ Program the EEPROM via Bootloader

        Args:
            node_address (int): slave address to program
            data (bytearray): bytearray with the complete hex file content including addresses
        """

    @abstractmethod
    def read_flash(self,
                   node_address,
                   start_reading,
                   stop_reading,
                   key_a,
                   key_b):
        """ Download the FLASH content via Bootloader

        Args:
            node_address (int): slave address to read
            start_reading (int): start address start to read from
            stop_reading (int): last address to read from
            key_a (int): first 32bit part of key
            key_b (int): second 32bit part of key

        Return:
            bytearray: flash content
        """

    @abstractmethod
    def read_eeprom(self,
                    node_address,
                    start_reading,
                    stop_reading):
        """ Download the EEPROM content via Bootloader

        Args:
            node_address (int): slave address to read
            start_reading (int): start address start to read from
            stop_reading (int): last address to read from

        Return:
            bytearray: eeprom content
        """
