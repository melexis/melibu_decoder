""" PpmBusInterface
Python module with the interface definition for a ppm bus class

Copyright Melexis N.V.

This product includes software developed at Melexis N.V. (https://www.melexis.com).

Melexis N.V. has provided this code according to LICENSE file attached to repository
"""
from abc import ABC, abstractmethod
from pymlxabc.bus_interface import BusInterface


class PpmBusInterface(BusInterface, ABC):
    """ Abstract base class with methods to be defined by all ppm bus classes """
    _type_descriptor = 'ppm'

    @abstractmethod
    def send_enter_ppm_pattern(self, pattern_time):
        """ Send the enter ppm mode pattern on the bus

        Args:
            pattern_time (int): Time to transmit enter ppm mode pattern (in ms).
        """

    @abstractmethod
    def send_calibration_frame(self):
        """ Send the calibration frame on the bus """

    @abstractmethod
    def do_unlock_session(self, request_ack, mlx81330_49_fix):
        """ Send the unlock session on the bus

        Args:
            request_ack (bool): En/disable the usage/requesting of slave ack messages during this session.
            mlx81330_49_fix (bool): En/disable fix for JIRA MLX81330-49.

        Returns:
            int: the project id of the chip.
        """

    @abstractmethod
    def do_prog_keys_session(self, request_ack, mlx81330_49_fix, prog_keys):
        """ Send the programming keys session on the bus

        Args:
            request_ack (bool): En/disable the usage/requesting of slave ack messages during this session.
            mlx81330_49_fix (bool): En/disable fix for JIRA MLX81330-49.
            prog_keys (list of ints): The programming keys to be send.
        """

    @abstractmethod
    def do_ram_programming_session(self, request_ack, mlx81330_49_fix, ram_program):
        """ Send the ram programming session on the bus

        Args:
            request_ack (bool): En/disable the usage/requesting of slave ack messages during this session.
            mlx81330_49_fix (bool): En/disable fix for JIRA MLX81330-49.
            ram_program (bytearray): The ram program to be send.
        """

    @abstractmethod
    def do_flash_programming_session(self, request_ack, mlx81330_49_fix, block_erase, flash_program):
        """ Send the flash programming session on the bus

        Args:
            request_ack (bool): En/disable the usage/requesting of slave ack messages during this session.
            mlx81330_49_fix (bool): En/disable fix for JIRA MLX81330-49.
            block_erase (bool): En/disable block erase timeout.
            flash_program (bytearray): The flash program to be send.
        """

    @abstractmethod
    def do_eeprom_programming_session(self, request_ack, mlx81330_49_fix, eeprom_offset, eeprom_data):
        """ Send the eeprom programming session on the bus

        Args:
            request_ack (bool): En/disable the usage/requesting of slave ack messages during this session.
            mlx81330_49_fix (bool): En/disable fix for JIRA MLX81330-49.
            eeprom_offset (int): Offset to start programming in the eeprom (must be page aligned).
            eeprom_data (bytearray): The eeprom data to be written (must be page aligned).
        """

    @abstractmethod
    def do_flash_crc_session(self, mlx81330_49_fix, flash_length):
        """ Send a flash crc read session command

        Args:
            mlx81330_49_fix (bool): En/disable fix for JIRA MLX81330-49.
            flash_length (int): number of bytes to calculate the crc for; calculation always starts
                 at address 0; will be page aligned.

        Returns:
            int: the flash crc value (24-bit BIST)
        """

    @abstractmethod
    def do_chip_reset_session(self, request_ack, mlx81330_49_fix):
        """ Send the chip reset session on the bus

        Args:
            request_ack (bool): En/disable the usage/requesting of slave ack messages during this session.
            mlx81330_49_fix (bool): En/disable fix for JIRA MLX81330-49.

        Returns:
            int: the project id of the chip.
        """
