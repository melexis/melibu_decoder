""" DeviceManager
Python module with the definition for a device

Copyright Melexis N.V.

This product includes software developed at Melexis N.V. (https://www.melexis.com).

Melexis N.V. has provided this code according to LICENSE file attached to repository
"""
from pymlxabc.control_interface import ControlInterface
from pymlxabc.device_interface import DeviceInterface
from pymlxabc.exceptions import DeviceManagerException


class DeviceManager(DeviceInterface):
    """ Generic device manager implementation

    Attributes:
        device_separator (str): separator for splitting devices in several levels.
        device_wildcard (str): wildcard symbol for the device identifier string lookup.
    """
    device_separator = "/"
    device_wildcard = "*"

    def __init__(self, **kwargs):
        """ Constructor """
        super().__init__(**kwargs)
        self._hw_control_int_dict = {}
        self._device_int_dict = {}

    def __exit__(self, exc_type, exc_value, traceback):
        """ Destructor """
        self.close_all()

    def __str__(self):
        return "Generic device manager object on {comm}".format(comm=self.get_hw_control())

    def open_all(self, port):
        """ Open and initiate the connection to the device and it's sub devices/controls

        Args:
            port (str): port to be used for communication.
        """
        for control_obj in self._hw_control_int_dict.values():
            control_obj.open(port)
        for device_obj in self._device_int_dict.values():
            device_obj.open_all(port)

    def close_all(self):
        """ Terminates the connection to the device """
        for device_obj in self._device_int_dict.values():
            device_obj.close_all()
        for device_obj in self._hw_control_int_dict.values():
            device_obj.close()

    @property
    def is_opened(self):
        """ bool: True if connection to device is established """
        opened = True
        for control_int in self._hw_control_int_dict.values():
            if not control_int.is_opened:
                opened = False
        for device_int in self._device_int_dict.values():
            if not device_int.is_opened:
                opened = False
        return opened

    def bind_hw_control(self, control_type, control_obj):
        """ Bind a hardware control object to this device

        The hardware control object(s) are used for communication from
        PC to some hardware device such as MUM, PTC, FPGA, ...

        Args:
            control_type (str): identifier string for the hardware control object.
            control_obj (ControlInterface): new device hardware control object to bind to.

        Raises:
            DeviceManagerException: Incorrect control provided
        """
        if not isinstance(control_obj, ControlInterface):
            raise DeviceManagerException("Incorrect control provided")
        if control_type in self._hw_control_int_dict:
            self._hw_control_int_dict[control_type].close()
        self._hw_control_int_dict[control_type] = control_obj

    def unbind_hw_control(self, control_type):
        """ Unbind a hardware control object from this device

        Args:
            control_type (str): identifier string for the hardware control object.
        """
        if control_type in self._hw_control_int_dict:
            self._hw_control_int_dict[control_type].close()
            del self._hw_control_int_dict[control_type]

    def get_hw_control(self, control_type=None):
        """ Getter for a hardware control object from this device

        Args:
            control_type (str): identifier string for the hardware control object.

        Returns:
            ControlInterface: requested hardware control object.

        Raises:
            DeviceManagerException: No hw control objects available
            DeviceManagerException: Multiple hw control objects found, please specify unique identifier
        """
        if not self._hw_control_int_dict.values():
            raise DeviceManagerException("No hw control objects available")

        if control_type is None:
            # type is not defined so return the first/only object
            if len(self._hw_control_int_dict.values()) > 1:
                raise DeviceManagerException("Multiple hw control objects found, please specify unique identifier")
            return list(self._hw_control_int_dict.values())[0]
        return self._hw_control_int_dict[control_type]

    def enum_hw_controls(self):
        """ Get all the identifiers for all the hw control items (recursive)

        Returns:
            list of str: list of hw control identifiers for this device
        """
        return list(self._hw_control_int_dict.keys())

    def bind_device(self, device_type, device_obj):
        """ Bind a device interface to this device

        The device object(s) are a kind of peripherals in the hardware device (MUM, PTC, FPGA, ...)
        For example a device could be a communication bus (LIN, Melibu, Fast, PPM,...), an EEPROM memory
        on the device, a LED on the device, an IO, ...

        Args:
            device_type (str): identifier string for the device interface.
            device_obj (DeviceInterface): new master interface to bind to.

        Raises:
            DeviceManagerException: Incorrect device provided
        """
        if not isinstance(device_obj, DeviceInterface):
            raise DeviceManagerException("Incorrect device provided")
        if device_type in self._device_int_dict:
            self._device_int_dict[device_type].close_all()
        self._device_int_dict[device_type] = device_obj

    def unbind_device(self, device_type):
        """ Unbind a hardware control object from this device

        Args:
            device_type (str): identifier string for the device interface.
        """
        if device_type in self._device_int_dict:
            self._device_int_dict[device_type].close_all()
            del self._device_int_dict[device_type]

    def get_device(self, device_type):
        """ Getter for a device object from this device manager

        Args:
            device_type (str): identifier string for the requested device object.

        Returns:
            DeviceInterface: requested device object

        Raises:
            DeviceManagerException: Device type not found
            DeviceManagerException: Multiple device objects found, please specify unique identifier
        """
        devices_found = self.get_devices(device_type)
        if not devices_found:
            raise DeviceManagerException("Device type not found")
        if len(devices_found) > 1:
            raise DeviceManagerException("Multiple device objects found, please specify unique identifier")
        return devices_found[0]

    def get_devices_keys(self, device_type):
        """ Getter for a list of device identifier strings from this device manager

        Args:
            device_type (str): identifier string for the requested device object.
        """
        sub_device = None
        parent_device = device_type
        if self.device_separator in device_type:
            # seems a nested device is requested, let's start with the parent
            device_splitted = device_type.split(self.device_separator, 1)
            parent_device = device_splitted[0]
            sub_device = device_splitted[1]

        filtered = []
        if self.device_wildcard in parent_device:
            # we need to provide a list of device
            device_splitted = parent_device.split(self.device_wildcard, 1)
            left_part = device_splitted[0]
            for key in self._device_int_dict:
                if key.startswith(left_part):
                    filtered.append(key)
        elif parent_device in self._device_int_dict:
            filtered.append(parent_device)

        if sub_device:
            sub_filtered = []
            for dev in filtered:
                sub_filtered = sub_filtered + dev.get_devices_keys(sub_device)
            return sub_filtered
        return filtered

    def get_devices(self, device_type):
        """ Getter for a list of device object(s) from this device manager

        Args:
            device_type (str): identifier string for the requested device object.

        Returns:
            list of DeviceInterface: requested device object
        """
        sub_device = None
        parent_device = device_type
        if self.device_separator in device_type:
            # seems a nested device is requested, let's start with the parent
            device_splitted = device_type.split(self.device_separator, 1)
            parent_device = device_splitted[0]
            sub_device = device_splitted[1]

        devices_objs = []
        if self.device_wildcard in parent_device:
            # we need to provide a list of device
            device_splitted = parent_device.split(self.device_wildcard, 1)
            left_part = device_splitted[0]
            for key, val in self._device_int_dict.items():
                if key.startswith(left_part):
                    devices_objs.append(val)
        elif parent_device in self._device_int_dict:
            devices_objs.append(self._device_int_dict[parent_device])

        if sub_device:
            sub_devices_objs = []
            for dev in devices_objs:
                sub_devices_objs = sub_devices_objs + dev.get_devices(sub_device)
            return sub_devices_objs
        return devices_objs

    def enum_devices(self):
        """ Get all the identifiers for all the devices in this device (recursive)

        Returns:
            list of str: list of device identifiers for this device
        """
        devices_list = self.get_devices_keys("*")
        for device_key, device_int in self._device_int_dict.items():
            sub_devices_list = device_int.enum_devices()
            devices_list = devices_list + [device_key + "/" + sub_key for sub_key in sub_devices_list]
        return devices_list

    def test_device(self, device_type):
        """ Test is a specific device object exists in this device manager

        Args:
            device_type (str): identifier string for the requested device object.

        Returns:
            bool: whether at least 1 device of the requested type exists in this device manager.
        """
        return bool(self.get_devices(device_type))
