""" SignalMuxInterface
Python module with the interface definition for a signal mux class

Copyright Melexis N.V.

This product includes software developed at Melexis N.V. (https://www.melexis.com).

Melexis N.V. has provided this code according to LICENSE file attached to repository
"""
from abc import ABC, abstractmethod
from pymlxabc.device_interface import DeviceInterface


class SignalMuxInterface(DeviceInterface, ABC):
    """ Abstract base class with methods to be defined by all signal mux classes """

    @abstractmethod
    def enable(self, channel=0):
        """ Enables a specific signal mux output

        Args:
            channel (int): mux output channel number to enable.
        """

    @abstractmethod
    def disable(self):
        """ Disables the signal mux output """
