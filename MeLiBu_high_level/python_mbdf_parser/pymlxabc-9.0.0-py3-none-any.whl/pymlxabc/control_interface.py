""" ControlInterface
Python module with the interface definition for a hardware control class

Copyright Melexis N.V.

This product includes software developed at Melexis N.V. (https://www.melexis.com).

Melexis N.V. has provided this code according to LICENSE file attached to repository
"""
from abc import ABC, abstractmethod


class ControlInterface(ABC):
    """ Abstract base class with methods to be defined by all hardware control classes """

    @abstractmethod
    def open(self, port):
        """ Open and initiate the connection to the device

        Args:
            port (str): port to be used for communication.
        """

    @abstractmethod
    def close(self):
        """ Terminates the connection to the device """

    @property
    def is_opened(self):
        """ bool: True if connection to device is established """
