"""
Python module which provides all the pymelibuframe exceptions

Copyright Melexis N.V.

This product includes software developed at Melexis N.V. (https://www.melexis.com).

Melexis N.V. has provided this code according to LICENSE file attached to repository
"""


class MelibuFrameBaseException(Exception):
    """ Custom base exception for the pymelibuframe module """

    def __init__(self, message, errors=None):
        """ Constructor

        Args:
            message (str): basic string describing the error.
            errors (dict): extended error information packet in a dictionary.
        """
        super().__init__(message)
        self.errors = errors

    def get_error(self, error_name):
        """ Gets the error value that belongs the specified error from the errors dict.

        Args:
            error_name (str): Name of the error, which should be a key in the errors dict.

        Returns:
            Error value if the specified error is stored in the errors dict, or None when it isn't.
        """
        if isinstance(self.errors, dict) and error_name in self.errors.keys():
            return self.errors[error_name]
        return None


class MelibuFrameException(MelibuFrameBaseException):
    """ Custom exception class for the MelibuFrame class """
