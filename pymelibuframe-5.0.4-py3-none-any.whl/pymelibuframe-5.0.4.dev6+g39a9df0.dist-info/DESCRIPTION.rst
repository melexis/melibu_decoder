Melexis Python classes which handle basic Melibu Frames to be used by Melibu Master implementations.

