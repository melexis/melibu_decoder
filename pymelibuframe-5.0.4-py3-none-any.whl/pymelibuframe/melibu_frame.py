""" MelibuFrame
Python module for handling melibu frames

Copyright Melexis N.V.

This product includes software developed at Melexis N.V. (https://www.melexis.com).

Melexis N.V. has provided this code according to LICENSE file attached to repository
"""
from abc import ABC, abstractmethod

from pymlxabc import (Melibu2FrameInterface, MelibuFrameInterface,
                      MelibuFrameInterfaceBase)

from pymelibuframe.exceptions import MelibuFrameException


class MelibuFrameBase(MelibuFrameInterfaceBase, ABC):
    """ Class which represents a standard Melibu frame """
    # pylint: disable=too-many-instance-attributes

    # slave node address
    BROADCAST_0 = 0x00
    BROADCAST_1 = 0x01
    BROADCAST_2 = 0x02
    BROADCAST_3 = 0x03
    MAX_SLAVE_ADDR = 0x3F
    # master_to_slave
    SLAVE_RECEIVE = True
    SLAVE_TRANSMIT = False

    FUNCTION_TYPE = "Unknown"

    def __init__(self, **kwargs):
        """ Constructor """
        super().__init__(**kwargs)
        self._name = None
        self._master_to_slave = False
        self._baudrate = 1000000
        self._slave_addr = 0x00
        self._payload = bytearray()
        self._check_ack = False
        self._header = None
        self._crc = None
        self._state = None

    @abstractmethod
    def __str__(self):
        pass

    @property
    def function_type(self):
        """ string: function type of this frame """
        return self.FUNCTION_TYPE

    @property
    def name(self):
        """ string: frame name """
        return self._name

    @name.setter
    def name(self, value):
        self._name = str(value)

    @property
    def master_to_slave(self):
        """ bool: True for master 2 slave, False for slave 2 master """
        return self._master_to_slave

    @master_to_slave.setter
    def master_to_slave(self, value):
        self._master_to_slave = value

    @property
    def r_t_bit(self):
        """ int: 1 for slave 2 master, 0 for master 2 slave """
        return int(not self.master_to_slave)

    @property
    def baudrate(self):
        """ int: baudrate for this frame """
        return self._baudrate

    @baudrate.setter
    def baudrate(self, value):
        self._baudrate = value

    @property
    def check_ack(self):
        """ bool: True if the slave acknowledge needs to be checked """
        return self._check_ack

    @check_ack.setter
    def check_ack(self, value):
        self._check_ack = value

    @property
    def slave_address(self):
        """ int: the slave address of this frame """
        return self._slave_addr

    @slave_address.setter
    def slave_address(self, value):
        self._slave_addr = value & self.MAX_SLAVE_ADDR

    @property
    def payload(self):
        """ bytearray: the payload of this frame """
        return self._payload

    @payload.setter
    def payload(self, data):
        self._payload = data

    @property
    def header(self):
        """ bytearray: the header of this frame """
        return self._header

    @header.setter
    def header(self, data):
        self._header = data

    @property
    def crc(self):
        """ bytearray: the crc of this frame """
        return self._crc

    @crc.setter
    def crc(self, data):
        self._crc = data

    @property
    def state(self):
        """ int: state of the frame. Shall be updated by the Melibu master after
                 transmission. Can be translated to human readable using
                 the function decode_melibu_frame_state from MelibuLowLevel.
                 When set to None the state is unknown.
        """
        return self._state

    @state.setter
    def state(self, state):
        self._state = state

    @property
    def size(self):
        """ int: payload size in bytes """

    def receive_post_process(self):
        """ Execute actions after receiving this frame """

    def transmit_pre_process(self, node, signal_values=()):
        """ Executes actions before transmitting this frame

        Args:
             node (SlaveNode): Slave node to communicate with
             signal_values (list): Signal values to apply before sending
        """


class Melibu1Frame(MelibuFrameBase, MelibuFrameInterface):
    """ Melibu 1.x standard frame class """

    MAX_SLAVE_ADDR = 0x3F
    # ext-instructions
    INSTR_1 = 0x01
    INSTR_2 = 0x02
    INSTR_3 = 0x03
    INSTR_4 = 0x04
    INSTR_5 = 0x05
    INSTR_6 = 0x06
    INSTR_7 = 0x07
    MAX_SUB_INSTR = 0x07
    # sub-addresses
    LEN_0 = 0b000000
    LEN_6 = 0b000001
    LEN_12 = 0b000011
    LEN_18 = 0b000111
    LEN_24 = 0b001111
    LEN_30 = 0b011111
    LEN_36 = 0b111111

    NORMAL_MODE = 0x00
    EXTENDED_MODE = 0x01
    MODE_DICT = {
        0: "normal",
        1: "extended",
    }

    def __init__(self, **kwargs):
        """ Constructor """
        super().__init__(**kwargs)
        self._sub_addr = 0x00
        self._mode = self.NORMAL_MODE
        self._ext_instr = 0x00

    def __str__(self):
        payload = " ".join([f"0x{b:02X}" for b in self._payload])
        return (f"Melibu v1 {'M2S' if self.master_to_slave else 'S2M'} "
                f"{self.function_type} frame "
                f"(node=0x{self.slave_address:02X} "
                f"sub-addr=0x{self.sub_address:02X} "
                f"data={payload} "
                f"ack={self.check_ack} name={self.name} state={self.state})")

    @property
    def sub_address(self):
        """ int: the sub address for this frame """
        return self._sub_addr

    @sub_address.setter
    def sub_address(self, value):
        self._sub_addr = value & self.MAX_SUB_INSTR


class Melibu1LedFrame(Melibu1Frame):
    """ Melibu 1.x LED frame class """

    FUNCTION_TYPE = "LED"
    MAX_SUB_INSTR = 0x3F

    def __str__(self):
        payload = " ".join([f"0x{b:02X}" for b in self._payload])
        return (f"Melibu v1 {'M2S' if self.master_to_slave else 'S2M'} "
                f"{self.function_type} frame "
                f"(node=0x{self.slave_address:02X} "
                f"sub-addr=0x{self.sub_address:02X} "
                f"mode={self.MODE_DICT[self.mode]} "
                f"data={payload} "
                f"ack={self.check_ack} name={self.name} state={self.state})")

    @property
    def mode(self):
        """ int: the mode for this frame """
        return self._mode

    @mode.setter
    def mode(self, value):
        self._mode = value & 0x01

    @property
    def ext_instruction(self):
        """ int: the ext instruction for this frame """
        raise MelibuFrameException("LED frame does not support ext instructions")

    @ext_instruction.setter
    def ext_instruction(self, value):
        raise MelibuFrameException("LED frame does not support ext instructions")

    @property
    def size(self):
        """ int: payload size in bytes """
        if self.mode == self.EXTENDED_MODE:
            return (int(self.sub_address) + 1) * 2
        return bin(int(self.sub_address)).count('1') * 6


class Melibu1CommandFrame(Melibu1Frame):
    """ Melibu 1.x Command frame class """

    FUNCTION_TYPE = "Command"

    def __str__(self):
        payload = " ".join([f"0x{b:02X}" for b in self._payload])
        return (f"Melibu v1 {'M2S' if self.master_to_slave else 'S2M'} "
                f"{self.function_type} frame "
                f"(node=0x{self.slave_address:02X} "
                f"sub-addr=0x{self.sub_address:02X} "
                f"ext=0x{self.ext_instruction:02X} "
                f"data={payload} "
                f"ack={self.check_ack} name={self.name} state={self.state})")

    @property
    def mode(self):
        """ int: the mode for this frame """
        raise MelibuFrameException("COMMAND frame does not support melibu mode setting")

    @mode.setter
    def mode(self, value):
        raise MelibuFrameException("COMMAND frame does not support melibu mode setting")

    @property
    def ext_instruction(self):
        """ int: the ext instruction for this frame """
        return self._ext_instr

    @ext_instruction.setter
    def ext_instruction(self, value):
        self._ext_instr = value & self.MAX_SUB_INSTR

    @property
    def size(self):
        """ int: payload size in bytes """
        return bin(int(self.sub_address)).count('1') * 6


class Melibu2Frame(MelibuFrameBase, Melibu2FrameInterface):
    """ Melibu 2.x standard frame class """

    MAX_SLAVE_ADDR = 0xFF
    MAX_PL_LENGTH = 0x7
    MAX_INSTR_WORD = 0xFFFF

    def __init__(self, **kwargs):
        """ Constructor """
        super().__init__(**kwargs)
        self._pl_length = 0x0
        self._instruction_word = 0x0
        self._i_bit = 0b0

    def __str__(self):
        payload = " ".join([f"0x{b:02X}" for b in self._payload])
        return (f"Melibu v2 {'M2S' if self.master_to_slave else 'S2M'} "
                f"{self.function_type} frame "
                f"(node=0x{self.slave_address:02X} "
                f"pl_length=0x{self.pl_length:02X} "
                f"instr=0x{self.instruction_word:04X} "
                f"i_bit={bool(self.i_bit)} "
                f"payload={payload} "
                f"ack={self.check_ack} name={self.name} state={self.state})")

    @property
    def pl_length(self):
        """ int: the pl_length parameter for determining the payload length """
        return self._pl_length

    @pl_length.setter
    def pl_length(self, value):
        self._pl_length = value & self.MAX_PL_LENGTH

    @property
    def instruction_word(self):
        """ int: the instruction word as an integer value """
        return self._instruction_word

    @property
    def instruction_word_bytes(self):
        """ bytes: the instruction word as a bytes object """
        return int.to_bytes(self.instruction_word, 2, "little")

    @instruction_word.setter
    def instruction_word(self, value):
        if isinstance(value, (bytes, bytearray)):
            value = int.from_bytes(value, "little")
        self._instruction_word = value & self.MAX_INSTR_WORD

    @property
    def i_bit(self):
        """ int: 1 if the instruction word must be added before the payload, 0 otherwise """
        return self._i_bit

    @i_bit.setter
    def i_bit(self, value):
        self._i_bit = value & 1


class Melibu2LedFrame(Melibu2Frame):
    """ Melibu 2.x LED Frame class """

    FUNCTION_TYPE = "LED"
    PL_LENGTH_SIZE = [6, 12, 24, 36, 48, 60, 84, 128]

    @property
    def size(self):
        """ int: payload size in bytes """
        return self.PL_LENGTH_SIZE[self.pl_length]


class Melibu2CommandFrame(Melibu2Frame):
    """ Melibu 2.x Command Frame class """

    FUNCTION_TYPE = "Command"
    PL_LENGTH_SIZE = [0, 2, 4, 6, 8, 10, 18, 24]

    @property
    def size(self):
        """ int: payload size in bytes """
        return self.PL_LENGTH_SIZE[self.pl_length]
